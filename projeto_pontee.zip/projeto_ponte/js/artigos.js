const form = document.getElementById("form-artigo");
const lista = document.getElementById("lista-artigos");
const meusArtigos = document.getElementById("meus-artigos"); // só existe se estiver logado
const busca = document.getElementById("busca");

function mostrarMensagem(texto, deuCerto) {
    const mensagem = document.getElementById("msg-artigo");
    mensagem.textContent = texto;
    mensagem.className = deuCerto ? "mensagem sucesso" : "mensagem erro";
}

// monta o cartão de um artigo (usado nas duas listas)
function criarCartao(artigo) {
    const li = document.createElement("li");

    const titulo = document.createElement("h3");
    const link = document.createElement("a");
    link.href = "artigo.php?id=" + artigo.id;   // abre o artigo inteiro (GET)
    link.textContent = artigo.titulo;
    titulo.append(link);

    const previa = document.createElement("p");
    previa.textContent = artigo.previa;

    const detalhes = document.createElement("p");
    detalhes.className = "detalhes";
    detalhes.textContent = "Por " + artigo.autor + " · " + artigo.data;

    li.append(titulo, previa, detalhes);
    return li;
}

// ---------- Artigos publicados ----------
async function carregarArtigos() {
    try {
        const resposta = await fetch(`listar_artigos.php?busca=${encodeURIComponent(busca.value)}`);

        if (!resposta.ok) {
            throw new Error(`Erro HTTP: ${resposta.status}`);
        }

        const artigos = await resposta.json();

        lista.innerHTML = "";

        if (artigos.length == 0) {
            if (busca.value != "") {
                lista.innerHTML = '<li class="vazio">Nenhum artigo encontrado com essa palavra.</li>';
            } else {
                lista.innerHTML = '<li class="vazio">Nenhum artigo publicado ainda. Que tal escrever o primeiro?</li>';
            }
            return;
        }

        for (const artigo of artigos) {
            lista.append(criarCartao(artigo));
        }
    } catch (erro) {
        console.error("Erro ao buscar artigos:", erro);
        lista.innerHTML = '<li class="vazio">Não foi possível carregar os artigos. Confira se o XAMPP está ligado.</li>';
    }
}

// ---------- Meus artigos (com botões Publicar / Remover) ----------
async function carregarMeusArtigos() {
    try {
        const resposta = await fetch("listar_artigos.php?meus=1");
        const artigos = await resposta.json();

        meusArtigos.innerHTML = "";

        if (artigos.length == 0) {
            meusArtigos.innerHTML = '<li class="vazio">Você ainda não escreveu nenhum artigo.</li>';
            return;
        }

        for (const artigo of artigos) {
            const li = criarCartao(artigo);

            const etiqueta = document.createElement("span");
            etiqueta.className = artigo.situacao == "Publicado" ? "etiqueta verde" : "etiqueta amarelo";
            etiqueta.textContent = artigo.situacao;
            li.insertBefore(etiqueta, li.children[1]);

            if (artigo.situacao == "Rascunho") {
                const publicar = document.createElement("button");
                publicar.type = "button";
                publicar.className = "botao-secundario";
                publicar.textContent = "Publicar";
                publicar.addEventListener("click", () => alterarArtigo(artigo.id, "publicar"));
                li.append(publicar);
            }

            const remover = document.createElement("button");
            remover.type = "button";
            remover.className = "botao-secundario";
            remover.textContent = "Remover";
            remover.addEventListener("click", () => alterarArtigo(artigo.id, "remover"));
            li.append(" ", remover);

            meusArtigos.append(li);
        }
    } catch (erro) {
        console.error("Erro ao buscar meus artigos:", erro);
    }
}

// ---------- Publicar rascunho / remover ----------
async function alterarArtigo(id, acao) {
    try {
        const resposta = await fetch("alterar_artigo.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id: id,
                acao: acao
            })
        });

        const dados = await resposta.json();

        mostrarMensagem(dados.mensagem, dados.sucesso);

        if (dados.sucesso) {
            carregarArtigos();
            carregarMeusArtigos();
        }
    } catch (erro) {
        mostrarMensagem("Não foi possível alterar agora. Tente novamente.", false);
    }
}

// ---------- Salvar artigo novo (POST com JSON) ----------
async function salvarArtigo() {
    const titulo = document.getElementById("titulo").value.trim();
    const conteudo = document.getElementById("conteudo").value.trim();
    const situacao = document.getElementById("situacao").value;

    if (titulo.length < 5) {
        mostrarMensagem("O título precisa ter pelo menos 5 caracteres.", false);
        return;
    }
    if (conteudo.length < 50) {
        mostrarMensagem("O texto precisa ter pelo menos 50 caracteres.", false);
        return;
    }

    try {
        const resposta = await fetch("salvar_artigo.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                titulo: titulo,
                conteudo: conteudo,
                situacao: situacao
            })
        });

        const dados = await resposta.json();

        mostrarMensagem(dados.mensagem, dados.sucesso);

        if (dados.sucesso) {
            form.reset();
            atualizarContador();
            carregarArtigos();
            carregarMeusArtigos();
        }
    } catch (erro) {
        mostrarMensagem("Não foi possível salvar agora. Tente novamente.", false);
    }
}

// mostra quantos caracteres já foram escritos
function atualizarContador() {
    const total = document.getElementById("conteudo").value.length;
    document.getElementById("contador").textContent = total + " caracteres (mínimo 50)";
}

// ---------- Listeners ----------

// busca: espera a pessoa parar de digitar um pouquinho antes de buscar
let esperaBusca = null;
busca.addEventListener("input", () => {
    clearTimeout(esperaBusca);
    esperaBusca = setTimeout(carregarArtigos, 300);
});

if (form != null) {
    document.getElementById("conteudo").addEventListener("input", atualizarContador);

    form.addEventListener("submit", async (evento) => {
        evento.preventDefault();
        await salvarArtigo();
    });

    carregarMeusArtigos();
}

carregarArtigos();
