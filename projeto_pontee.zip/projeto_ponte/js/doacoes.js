const formSolicitacao = document.getElementById("form-solicitacao");
const formDoacao = document.getElementById("form-doacao");
const listaSolicitacoes = document.getElementById("lista-solicitacoes");
const listaDoacoes = document.getElementById("lista-doacoes");
const filtroSolicitacao = document.getElementById("filtro-solicitacao");

// guarda as solicitações abertas para usar no select da doação
let solicitacoesAbertas = [];

// ---------- Funções de apoio ----------

function corDaUrgencia(urgencia) {
    switch (urgencia) {
        case "Alta":
            return "vermelho";
        case "Média":
            return "amarelo";
        default:
            return "verde"; // Baixa
    }
}

function corDaSituacao(situacao) {
    switch (situacao) {
        case "Aberta":
        case "Disponível":
            return "verde";
        case "Em andamento":
        case "Reservada":
            return "amarelo";
        default:
            return "cinza"; // Atendida, Cancelada, Entregue
    }
}

function criarEtiqueta(texto, cor) {
    const etiqueta = document.createElement("span");
    etiqueta.className = "etiqueta " + cor;
    etiqueta.textContent = texto;
    return etiqueta;
}

// 50 -> "R$ 50,00"   |   2 -> "2"
function formatarQuantidade(item, quantidade) {
    if (item == "Dinheiro") {
        return "R$ " + quantidade.toFixed(2).replace(".", ",");
    }
    return String(quantidade).replace(".", ",");
}

function mostrarMensagem(id, texto, deuCerto) {
    const mensagem = document.getElementById(id);
    mensagem.textContent = texto;
    mensagem.className = deuCerto ? "mensagem sucesso" : "mensagem erro";
}

// ---------- Solicitações ----------

async function carregarSolicitacoes() {
    try {
        const resposta = await fetch(`listar_solicitacoes.php?filtro=${filtroSolicitacao.value}`);

        if (!resposta.ok) {
            throw new Error(`Erro HTTP: ${resposta.status}`);
        }

        const solicitacoes = await resposta.json();

        listaSolicitacoes.innerHTML = "";

        if (solicitacoes.length == 0) {
            listaSolicitacoes.innerHTML = '<li class="vazio">Nenhuma solicitação encontrada.</li>';
            return;
        }

        for (const s of solicitacoes) {
            const li = document.createElement("li");

            const titulo = document.createElement("h3");
            titulo.textContent = s.item;

            const texto = document.createElement("p");
            texto.textContent = s.descricao;

            const detalhes = document.createElement("p");
            detalhes.className = "detalhes";
            detalhes.textContent = "Solicitação " + s.id + " · " + s.data + " · por " + s.autor;

            li.append(
                titulo,
                criarEtiqueta("Urgência " + s.urgencia, corDaUrgencia(s.urgencia)),
                criarEtiqueta(s.situacao, corDaSituacao(s.situacao)),
                texto,
                detalhes
            );

            // botão para doar direto para essa solicitação
            const aindaPrecisa = s.situacao == "Aberta" || s.situacao == "Em andamento";

            if (logado && aindaPrecisa) {
                const botao = document.createElement("button");
                botao.type = "button";
                botao.className = "botao-secundario";
                botao.textContent = "Quero ajudar";
                botao.addEventListener("click", () => escolherSolicitacao(s));
                li.append(botao);
            }

            listaSolicitacoes.append(li);
        }
    } catch (erro) {
        console.error("Erro ao buscar solicitações:", erro);
        listaSolicitacoes.innerHTML = '<li class="vazio">Não foi possível carregar as solicitações.</li>';
    }
}

// preenche o select "Para quem?" do formulário de doação
async function carregarSelectSolicitacoes() {
    const select = document.getElementById("id_solicitacao");

    try {
        const resposta = await fetch("listar_solicitacoes.php?filtro=abertas");
        solicitacoesAbertas = await resposta.json();

        select.innerHTML = '<option value="">Doação geral (sem solicitação)</option>';

        for (const s of solicitacoesAbertas) {
            const opcao = document.createElement("option");
            opcao.value = s.id;
            opcao.textContent = s.id + " - " + s.item + ": " + s.descricao;
            select.append(opcao);
        }
    } catch (erro) {
        console.error("Erro ao buscar solicitações:", erro);
    }
}

// quando clica em "Quero ajudar"
function escolherSolicitacao(solicitacao) {
    document.getElementById("id_solicitacao").value = solicitacao.id;
    document.getElementById("tipo_item").value = solicitacao.item;
    document.getElementById("bloco-doacao").scrollIntoView({ behavior: "smooth" });
    document.getElementById("quantidade").focus();
}

async function salvarSolicitacao() {
    const item = document.getElementById("item_solicitado").value;
    const urgencia = document.getElementById("urgencia").value;
    const descricao = document.getElementById("descricao_solicitacao").value.trim();

    if (item == "" || urgencia == "") {
        mostrarMensagem("msg-solicitacao", "Escolha o tipo e a urgência.", false);
        return;
    }
    if (descricao.length < 5) {
        mostrarMensagem("msg-solicitacao", "Descreva o que você precisa.", false);
        return;
    }

    try {
        const resposta = await fetch("salvar_solicitacao.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                item: item,
                urgencia: urgencia,
                descricao: descricao
            })
        });

        const dados = await resposta.json();

        mostrarMensagem("msg-solicitacao", dados.mensagem, dados.sucesso);

        if (dados.sucesso) {
            formSolicitacao.reset();
            carregarSolicitacoes();
            carregarSelectSolicitacoes();
        }
    } catch (erro) {
        mostrarMensagem("msg-solicitacao", "Não foi possível enviar agora. Tente novamente.", false);
    }
}

// ---------- Doações ----------

async function carregarDoacoes() {
    try {
        const resposta = await fetch("listar_doacoes.php");

        if (!resposta.ok) {
            throw new Error(`Erro HTTP: ${resposta.status}`);
        }

        const doacoes = await resposta.json();

        listaDoacoes.innerHTML = "";

        if (doacoes.length == 0) {
            listaDoacoes.innerHTML = '<li class="vazio">Nenhuma doação registrada ainda. Seja o primeiro!</li>';
            return;
        }

        for (const d of doacoes) {
            const li = document.createElement("li");

            const titulo = document.createElement("h3");
            titulo.textContent = d.item + " · " + formatarQuantidade(d.item, d.quantidade);

            li.append(titulo, criarEtiqueta(d.situacao, corDaSituacao(d.situacao)));

            if (d.descricao) {
                const texto = document.createElement("p");
                texto.textContent = d.descricao;
                li.append(texto);
            }

            const destino = document.createElement("p");
            destino.className = "detalhes";
            if (d.idSolicitacao) {
                destino.textContent = "Para a solicitação " + d.idSolicitacao + ": " + d.solicitacao;
            } else {
                destino.textContent = "Doação geral";
            }

            const detalhes = document.createElement("p");
            detalhes.className = "detalhes";
            detalhes.textContent = "Doação " + d.id + " · " + d.data + " · por " + d.autor;

            li.append(destino, detalhes);
            listaDoacoes.append(li);
        }
    } catch (erro) {
        console.error("Erro ao buscar doações:", erro);
        listaDoacoes.innerHTML = '<li class="vazio">Não foi possível carregar as doações.</li>';
    }
}

async function salvarDoacao() {
    const idSolicitacao = document.getElementById("id_solicitacao").value;
    const item = document.getElementById("tipo_item").value;
    const descricao = document.getElementById("descricao_doacao").value.trim();
    let quantidade = document.getElementById("quantidade").value.trim();

    // regex: aceita "2", "10", "50,00" ou "50.5"
    const formatoQuantidade = /^\d+([.,]\d{1,2})?$/;

    if (item == "") {
        mostrarMensagem("msg-doacao", "Escolha o tipo do que você vai doar.", false);
        return;
    }
    if (!formatoQuantidade.test(quantidade)) {
        mostrarMensagem("msg-doacao", "Digite só números na quantidade. Ex.: 2 ou 50,00", false);
        return;
    }

    quantidade = Number(quantidade.replace(",", "."));

    if (quantidade <= 0) {
        mostrarMensagem("msg-doacao", "A quantidade precisa ser maior que zero.", false);
        return;
    }

    try {
        const resposta = await fetch("salvar_doacao.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id_solicitacao: idSolicitacao,
                item: item,
                quantidade: quantidade,
                descricao: descricao
            })
        });

        const dados = await resposta.json();

        mostrarMensagem("msg-doacao", dados.mensagem, dados.sucesso);

        if (dados.sucesso) {
            formDoacao.reset();
            carregarDoacoes();
            carregarSolicitacoes(); // a solicitação pode ter mudado para "Em andamento"
        }
    } catch (erro) {
        mostrarMensagem("msg-doacao", "Não foi possível enviar agora. Tente novamente.", false);
    }
}

// ---------- Listeners ----------

filtroSolicitacao.addEventListener("change", carregarSolicitacoes);

// os formulários só existem quando a pessoa está logada
if (formSolicitacao != null) {
    formSolicitacao.addEventListener("submit", async (evento) => {
        evento.preventDefault();
        await salvarSolicitacao();
    });
}

if (formDoacao != null) {
    carregarSelectSolicitacoes();

    formDoacao.addEventListener("submit", async (evento) => {
        evento.preventDefault();
        await salvarDoacao();
    });
}

carregarSolicitacoes();
carregarDoacoes();
