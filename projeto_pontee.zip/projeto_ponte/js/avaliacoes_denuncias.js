const form = document.getElementById("form-avaliacao");   // só existe se estiver logado
const lista = document.getElementById("lista-avaliacoes");
const filtro = document.getElementById("filtro-local");
const resumo = document.getElementById("resumo");

// guarda os locais (com média e total de avaliações) que vêm do locais.php
let locais = [];

// ==================== Funções de apoio ====================

// mesma regra de cores da legenda do mapa
function corDaNota(nota) {
    if (nota >= 4) {
        return "verde";
    } else if (nota >= 2.5) {
        return "amarelo";
    } else {
        return "vermelho";
    }
}

// 4 -> "★★★★☆"
function estrelas(nota) {
    const cheias = Math.round(nota);
    return "★".repeat(cheias) + "☆".repeat(5 - cheias);
}

function mostrarMensagem(texto, deuCerto) {
    const mensagem = document.getElementById("msg-avaliacao");
    mensagem.textContent = texto;
    mensagem.className = deuCerto ? "mensagem sucesso" : "mensagem erro";
}

// ==================== Locais ====================

// preenche o filtro e o select do formulário
async function carregarLocais() {
    try {
        const resposta = await fetch("locais.php");
        locais = await resposta.json();

        const valorFiltro = filtro.value;
        filtro.innerHTML = '<option value="">Todos os locais</option>';

        const selectForm = document.getElementById("id_local"); // só existe se estiver logado
        if (selectForm != null) {
            selectForm.innerHTML = '<option value="">Escolha o local</option>';
        }

        for (const local of locais) {
            const opcao = document.createElement("option");
            opcao.value = local.id;
            opcao.textContent = local.nome;
            filtro.append(opcao);

            if (selectForm != null) {
                const opcaoForm = document.createElement("option");
                opcaoForm.value = local.id;
                opcaoForm.textContent = local.nome + " (" + local.bairro + ")";
                selectForm.append(opcaoForm);
            }
        }

        filtro.value = valorFiltro;
    } catch (erro) {
        console.error("Erro ao buscar locais:", erro);
    }
}

// mostra "Média 4,3 ★★★★☆ (2 avaliações)" do local escolhido
function mostrarResumo() {
    resumo.textContent = "";

    if (filtro.value == "") {
        return;
    }

    const local = locais.find((l) => l.id == filtro.value);

    if (local == undefined || local.media == null) {
        resumo.textContent = "Esse local ainda não foi avaliado.";
        return;
    }

    const media = String(local.media).replace(".", ",");
    resumo.textContent = "Média " + media + " " + estrelas(local.media) +
        " (" + local.totalAvaliacoes + " avaliações)";
}

// ==================== Lista ====================

async function carregarAvaliacoes() {
    try {
        // envia o local escolhido pela URL (GET)
        const resposta = await fetch(`listar_avaliacoes.php?id_local=${filtro.value}`);

        if (!resposta.ok) {
            throw new Error(`Erro HTTP: ${resposta.status}`);
        }

        const avaliacoes = await resposta.json();

        mostrarResumo();
        lista.innerHTML = "";

        if (avaliacoes.length == 0) {
            lista.innerHTML = '<li class="vazio">Nenhuma avaliação ainda.</li>';
            return;
        }

        for (const a of avaliacoes) {
            const li = document.createElement("li");

            const titulo = document.createElement("h3");
            titulo.textContent = a.local;

            const etiqueta = document.createElement("span");
            etiqueta.className = "etiqueta " + corDaNota(a.nota);
            etiqueta.textContent = estrelas(a.nota) + " " + String(a.nota).replace(".", ",");

            li.append(titulo, etiqueta);

            if (a.descricao) {
                const texto = document.createElement("p");
                texto.textContent = a.descricao;
                li.append(texto);
            }

            const detalhes = document.createElement("p");
            detalhes.className = "detalhes";
            detalhes.textContent = a.data + " · por " + a.autor;

            li.append(detalhes);
            lista.append(li);
        }
    } catch (erro) {
        console.error("Erro ao buscar avaliações:", erro);
        lista.innerHTML = '<li class="vazio">Não foi possível carregar. Confira se o XAMPP está ligado.</li>';
    }
}

// ==================== Enviar (POST com JSON) ====================

async function salvarAvaliacao() {
    const idLocal = document.getElementById("id_local").value;
    const nota = document.getElementById("nota").value;
    const descricao = document.getElementById("descricao").value.trim();

    if (idLocal == "" || nota == "") {
        mostrarMensagem("Escolha o local e a nota.", false);
        return;
    }
    if (descricao.length < 10) {
        mostrarMensagem("Descreva o problema com pelo menos 10 caracteres.", false);
        return;
    }

    try {
        const resposta = await fetch("salvar_avaliacao.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id_local: idLocal,
                nota: nota,
                descricao: descricao
            })
        });

        const dados = await resposta.json();

        // salvar_avaliacao.php responde com "ok" (é o mesmo arquivo que o mapa usa)
        mostrarMensagem(dados.mensagem, dados.ok);

        if (dados.ok) {
            form.reset();
            filtro.value = idLocal;   // mostra o local que acabou de ser avaliado
            atualizarTudo();
        }
    } catch (erro) {
        mostrarMensagem("Não foi possível enviar agora. Tente novamente.", false);
    }
}

// ==================== Juntando tudo ====================

// recarrega os locais (para a média ficar certa) e a lista
async function atualizarTudo() {
    await carregarLocais();
    carregarAvaliacoes();
}

filtro.addEventListener("change", carregarAvaliacoes);

if (form != null) {
    form.addEventListener("submit", async (evento) => {
        evento.preventDefault();
        await salvarAvaliacao();
    });
}

atualizarTudo();
