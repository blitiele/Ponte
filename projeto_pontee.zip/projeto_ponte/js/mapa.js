// ---------- Mapa ----------
const mapa = L.map('mapa').setView([-25.4370, -49.2700], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap'
}).addTo(mapa);

const camadaLocais = L.layerGroup().addTo(mapa);
let locais = [];

// ---------- Funções de apoio ----------
function escapar(texto) {
  const div = document.createElement('div');
  div.textContent = texto ?? '';
  return div.innerHTML;
}

function corDaNota(media) {
  if (media === null) return '#8a8f8f';
  if (media >= 4) return '#1a7f4b';
  if (media >= 2.5) return '#d49a00';
  return '#b3261e';
}

function textoNota(local) {
  if (local.media === null) return 'Sem avaliações';
  const palavra = local.totalAvaliacoes === 1 ? 'avaliação' : 'avaliações';
  return local.media.toFixed(1).replace('.', ',') + ' / 5 (' + local.totalAvaliacoes + ' ' + palavra + ')';
}

function endereco(local) {
  let texto = local.rua + ', ' + local.numero + ' - ' + local.bairro;
  if (local.complemento) texto += ' (' + local.complemento + ')';
  return texto;
}

function conteudoPopup(local) {
  let html =
    '<strong>' + escapar(local.nome) + '</strong><br>' +
    escapar(local.categoria) + '<br>' +
    escapar(endereco(local)) + '<br>' +
    '<b>Nota:</b> ' + textoNota(local) + '<br>' +
    '<b>Denúncias:</b> ' + local.denuncias.length;

  if (local.denuncias.length > 0) {
    html += '<ul class="popup-denuncias">';
    for (const d of local.denuncias.slice(0, 3)) {
      html += '<li>' + escapar(d.descricao) + ' <em>(' + escapar(d.situacao) + ', ' + d.data + ')</em></li>';
    }
    html += '</ul>';
  }

  return html;
}

// ---------- Desenhar mapa e lista ----------
function desenhar() {
  const categoria = document.getElementById('filtro-categoria').value;
  const filtrados = locais.filter(l => categoria === '' || l.categoria === categoria);
  const lista = document.getElementById('lista-locais');

  camadaLocais.clearLayers();
  lista.innerHTML = '';

  for (const local of filtrados) {
    const marcador = L.circleMarker([local.lat, local.lng], {
      radius: 10,
      color: '#ffffff',
      weight: 2,
      fillColor: corDaNota(local.media),
      fillOpacity: 0.9
    })
      .bindPopup(conteudoPopup(local))
      .addTo(camadaLocais);

    const item = document.createElement('li');
    item.innerHTML =
      '<button type="button" class="local-item">' +
        '<span class="local-nome">' + escapar(local.nome) + '</span>' +
        '<span class="local-info">' + escapar(local.categoria) + ' · ' + escapar(local.bairro) + '</span>' +
        '<span class="local-info">Nota: ' + textoNota(local) + ' · Denúncias: ' + local.denuncias.length + '</span>' +
      '</button>';

    item.querySelector('button').addEventListener('click', () => {
      mapa.setView([local.lat, local.lng], 16);
      marcador.openPopup();
    });

    lista.appendChild(item);
  }

  if (filtrados.length === 0) {
    lista.innerHTML = '<li class="vazio">Nenhum local encontrado.</li>';
  }

  document.getElementById('contador').textContent = '(' + filtrados.length + ')';
}

function preencherLocaisAvaliacao() {
  const select = document.getElementById('id_local');
  if (!select) return;

  select.innerHTML = '<option value="">Escolha o local</option>';
  for (const local of locais) {
    select.innerHTML += '<option value="' + escapar(local.id) + '">' + escapar(local.nome) + '</option>';
  }
}

// ---------- Buscar os locais no banco ----------
let primeiraVez = true;

async function carregarLocais() {
  try {
    const resposta = await fetch('locais.php');
    if (!resposta.ok) throw new Error();
    locais = await resposta.json();
    desenhar();
    preencherLocaisAvaliacao();

    if (primeiraVez && locais.length > 0) {
      mapa.fitBounds(locais.map(l => [l.lat, l.lng]), { padding: [40, 40] });
      primeiraVez = false;
    }
  } catch (erro) {
    document.getElementById('lista-locais').innerHTML =
      '<li class="vazio">Não foi possível carregar os locais. Confira se o XAMPP está ligado.</li>';
  }
}

// ---------- Enviar um formulário para o PHP ----------
async function enviar(form, arquivo, mensagem, dadosExtras) {
  const dados = new FormData(form);
  for (const nome in dadosExtras) {
    dados.append(nome, dadosExtras[nome]);
  }

  try {
    const resposta = await fetch(arquivo, { method: 'POST', body: dados });
    const resultado = await resposta.json();
    mensagem.textContent = resultado.mensagem;
    return resultado.ok;
  } catch (erro) {
    mensagem.textContent = 'Não foi possível enviar agora. Tente novamente.';
    return false;
  }
}

// ---------- Cadastrar local ----------
const formLocal = document.getElementById('form-local');
let pontoEscolhido = null;
let marcadorTemporario = null;

if (formLocal) {
  mapa.on('click', (evento) => {
    pontoEscolhido = evento.latlng;

    if (marcadorTemporario) mapa.removeLayer(marcadorTemporario);
    marcadorTemporario = L.marker(pontoEscolhido).addTo(mapa);

    document.getElementById('ponto-escolhido').textContent =
      'Ponto marcado: ' + pontoEscolhido.lat.toFixed(5) + ', ' + pontoEscolhido.lng.toFixed(5);
  });

  formLocal.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    const mensagem = document.getElementById('msg-local');

    if (pontoEscolhido === null) {
      mensagem.textContent = 'Clique no mapa para marcar onde fica o local.';
      return;
    }

    const deuCerto = await enviar(formLocal, 'salvar_local.php', mensagem, {
      latitude: pontoEscolhido.lat,
      longitude: pontoEscolhido.lng
    });

    if (deuCerto) {
      formLocal.reset();
      mapa.removeLayer(marcadorTemporario);
      marcadorTemporario = null;
      pontoEscolhido = null;
      document.getElementById('ponto-escolhido').textContent = 'Nenhum ponto marcado no mapa ainda.';
      carregarLocais();
    }
  });
}

// ---------- Avaliar local ----------
const formAvaliacao = document.getElementById('form-avaliacao');

if (formAvaliacao) {
  formAvaliacao.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    const mensagem = document.getElementById('msg-avaliacao');

    const deuCerto = await enviar(formAvaliacao, 'salvar_avaliacao.php', mensagem, {});

    if (deuCerto) {
      formAvaliacao.reset();
      carregarLocais();
    }
  });
}

// ---------- Início ----------
document.getElementById('filtro-categoria').addEventListener('change', desenhar);
carregarLocais();
