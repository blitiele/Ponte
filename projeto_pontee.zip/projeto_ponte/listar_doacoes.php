<?php
    include('conexao.php');

    header('Content-Type: application/json; charset=utf-8');

    // LEFT JOIN porque a doação pode não estar ligada a nenhuma solicitação
    $sql = "SELECT d.id_doacao, d.tipo_item, d.descricao_doacao, d.data_doacao,
                   d.quantidade_doada, d.situacao_doacao, d.id_solicitacao,
                   u.nome_usuario, s.descricao_solicitacao
            FROM doacao d
            JOIN usuario u ON u.cod_usuario = d.cod_usuario
            LEFT JOIN solicitacao s ON s.id_solicitacao = d.id_solicitacao
            ORDER BY d.data_doacao DESC, d.id_doacao DESC";

    $result = $conn->query($sql);

    $doacoes = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $doacoes[] = [
                "id" => $row["id_doacao"],
                "item" => $row["tipo_item"],
                "descricao" => $row["descricao_doacao"],
                "quantidade" => (float) $row["quantidade_doada"],
                "situacao" => $row["situacao_doacao"],
                "data" => date("d/m/Y", strtotime($row["data_doacao"])),
                "autor" => $row["nome_usuario"],
                "idSolicitacao" => $row["id_solicitacao"],
                "solicitacao" => $row["descricao_solicitacao"]
            ];
        }
    }

    $conn->close();

    echo json_encode($doacoes);
?>
