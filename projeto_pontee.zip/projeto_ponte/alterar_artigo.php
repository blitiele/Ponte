<?php
    // Publica um rascunho ou remove um artigo (só o autor pode)
    if (session_id() == "") {
        session_start();
    }

    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION["logado"])) {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Entre na sua conta."
        ]);
        exit;
    }

    $dados = json_decode(
        file_get_contents("php://input"),
        true
    );

    $id = isset($dados["id"]) ? $dados["id"] : "";
    $acao = isset($dados["acao"]) ? $dados["acao"] : "";
    $codUsuario = $_SESSION["cod_usuario"];

    // a ação vira a nova situação do artigo
    switch ($acao) {
        case "publicar":
            $novaSituacao = "Publicado";
            $mensagem = "Artigo publicado!";
            break;
        case "remover":
            $novaSituacao = "Removido";
            $mensagem = "Artigo removido.";
            break;
        default:
            echo json_encode([
                "sucesso" => false,
                "mensagem" => "Ação inválida."
            ]);
            exit;
    }

    include('conexao.php');

    $id = $conn->real_escape_string($id);

    // o "AND cod_usuario" garante que ninguém mexe no artigo dos outros
    // quando publica um rascunho, a data passa a ser a de hoje
    if ($novaSituacao == "Publicado") {
        $sql = "UPDATE artigo SET situacao_artigo = 'Publicado', data_publicacao = CURDATE()
                WHERE id_artigo = '$id' AND cod_usuario = '$codUsuario'";
    }
    else {
        $sql = "UPDATE artigo SET situacao_artigo = 'Removido'
                WHERE id_artigo = '$id' AND cod_usuario = '$codUsuario'";
    }

    if ($conn->query($sql) === TRUE && $conn->affected_rows > 0) {
        echo json_encode([
            "sucesso" => true,
            "mensagem" => $mensagem
        ]);
    }
    else {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Não foi possível alterar esse artigo."
        ]);
    }

    $conn->close();
?>
