<?php
    include('conexao.php');

    header('Content-Type: application/json; charset=utf-8');

    // listar_solicitacoes.php?filtro=abertas -> só as que ainda precisam de ajuda
    $filtro = isset($_GET["filtro"]) ? $_GET["filtro"] : "";

    $sql = "SELECT s.id_solicitacao, s.item_solicitado, s.descricao_solicitacao,
                   s.urgencia_solicitacao, s.data_solicitacao, s.situacao_solicitacao,
                   u.nome_usuario
            FROM solicitacao s
            JOIN usuario u ON u.cod_usuario = s.cod_usuario";

    if ($filtro == "abertas") {
        $sql = $sql . " WHERE s.situacao_solicitacao IN ('Aberta', 'Em andamento')";
    }

    // as mais urgentes primeiro, depois as mais novas
    $sql = $sql . " ORDER BY FIELD(s.urgencia_solicitacao, 'Alta', 'Média', 'Baixa'), s.data_solicitacao DESC";

    $result = $conn->query($sql);

    $solicitacoes = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $solicitacoes[] = [
                "id" => $row["id_solicitacao"],
                "item" => $row["item_solicitado"],
                "descricao" => $row["descricao_solicitacao"],
                "urgencia" => $row["urgencia_solicitacao"],
                "situacao" => $row["situacao_solicitacao"],
                "data" => date("d/m/Y", strtotime($row["data_solicitacao"])),
                "autor" => $row["nome_usuario"]
            ];
        }
    }

    $conn->close();

    echo json_encode($solicitacoes);
?>
