<?php
    if (session_id() == "") {
        session_start();
    }
    $logado = isset($_SESSION["logado"]);
    $nome = isset($_SESSION["nome_usuario"]) ? $_SESSION["nome_usuario"] : "";
    $pagina = "avaliacoes_denuncias.php";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Avaliações e denúncias | Ponte</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700&display=swap">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/paginas.css">
</head>
<body>

<header>
  <div class="acesso">
    <?php if ($logado) { ?>
      <span class="usuario"><?=htmlspecialchars($nome)?></span>
      <a href="logout.php">Sair</a>
    <?php } else { ?>
      <a href="login.php">Entrar</a>
      <a href="cadastro.php">Cadastrar</a>
    <?php } ?>
  </div>

  <h1>Avaliações e denúncias</h1>
  <p class="subtitulo">Dê uma nota de 0 a 5 para a acessibilidade do lugar e descreva o problema.</p>

  <?php include('menu.php'); ?>
</header>

<main>
  <section class="blocos">

    <!-- ===================== FORMULÁRIO ===================== -->
    <article class="bloco">
      <h2>Avaliar / denunciar um local</h2>

      <?php if ($logado) { ?>
        <form id="form-avaliacao">
          <label for="id_local">Local</label>
          <select id="id_local" required>
            <option value="">Carregando locais...</option>
          </select>
          <p class="dica">O local não está na lista? Cadastre ele primeiro no <a href="mapa.php">mapa</a>.</p>

          <label for="nota">Nota de acessibilidade</label>
          <select id="nota" required>
            <option value="">Escolha uma nota</option>
            <option value="5">5 - Excelente</option>
            <option value="4">4 - Boa</option>
            <option value="3">3 - Razoável</option>
            <option value="2">2 - Ruim</option>
            <option value="1">1 - Muito ruim</option>
            <option value="0">0 - Nada acessível</option>
          </select>

          <label for="descricao">Descrição do problema</label>
          <textarea id="descricao" rows="6" maxlength="500" required
            placeholder="Ex.: A entrada só tem escadas e não há rampa."></textarea>

          <button type="submit">Enviar</button>
          <p id="msg-avaliacao" class="mensagem" role="status"></p>
        </form>
      <?php } else { ?>
        <p class="aviso"><a href="login.php">Entre na sua conta</a> para avaliar ou denunciar um local.</p>
      <?php } ?>
    </article>

    <!-- ===================== LISTA ===================== -->
    <article class="bloco bloco-largo">
      <h2>Avaliações e denúncias registradas</h2>

      <label for="filtro-local">Ver local</label>
      <select id="filtro-local" class="filtro">
        <option value="">Todos os locais</option>
      </select>

      <p id="resumo" class="resumo"></p>

      <ul id="lista-avaliacoes" class="lista-cartoes"></ul>
    </article>

  </section>
</main>

<script src="js/avaliacoes_denuncias.js"></script>
</body>
</html>
