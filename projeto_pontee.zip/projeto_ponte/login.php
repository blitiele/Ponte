<?php
    if (session_id() == "") {
        session_start();
    }

    // se já está logado, volta para o início
    if (isset($_SESSION["logado"])) {
        header("Location: index.php");
        exit;
    }

    $erro = "";
    $aviso = isset($_SESSION["aviso_login"]) ? $_SESSION["aviso_login"] : "";
    unset($_SESSION["aviso_login"]);

    $login = isset($_POST["login"]) ? trim($_POST["login"]) : "";
    $senha = isset($_POST["senha"]) ? $_POST["senha"] : "";

    if (isset($_POST["btnEntrar"])) {

        if ($login == "" || $senha == "") {
            $erro = "Informe login e senha.";
        }
        else {
            include('conexao.php');

            $loginSeguro = $conn->real_escape_string($login);

            // dá para entrar com o nome de usuário OU com o e-mail
            $sql = "SELECT cod_usuario, nome_usuario, senha FROM usuario
                    WHERE nome_usuario = '$loginSeguro' OR email = '$loginSeguro'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();

                // password_verify: senhas criadas pelo cadastro (criptografadas)
                // comparação direta: usuários antigos inseridos pelo projeto_ponte.sql
                if (password_verify($senha, $row["senha"]) || $senha == $row["senha"]) {
                    $_SESSION["logado"] = true;
                    $_SESSION["cod_usuario"] = $row["cod_usuario"];
                    $_SESSION["nome_usuario"] = $row["nome_usuario"];

                    $conn->close();
                    header("Location: index.php");
                    exit;
                }
            }

            $erro = "Login ou senha incorretos.";
            $conn->close();
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Entrar · PONTE</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700&display=swap">
  <link rel="stylesheet" href="logcad.css">
</head>

<body>
  <main class="login">
    <section class="login__marca">
      <h1>PONTE</h1>
      <br>
    </section>

    <section class="login__acesso">
      <form class="login__form" method="post" action="login.php">
        <h2>Acesse sua conta</h2>

        <?php if ($erro != "") { ?>
          <p class="alerta alerta--erro" role="alert"><?=$erro?></p>
        <?php } ?>

        <?php if ($aviso != "") { ?>
          <p class="alerta alerta--info" role="status"><?=$aviso?></p>
        <?php } ?>

        <div class="campo">
          <label for="login">Login ou e-mail</label>
          <input type="text" id="login" name="login" autocomplete="username"
            value="<?=htmlspecialchars($login)?>" required autofocus>
        </div>

        <div class="campo">
          <label for="senha">Senha</label>
          <input type="password" id="senha" name="senha" autocomplete="current-password" required>
        </div>

        <button type="submit" name="btnEntrar" class="botao">Entrar</button>

        <p class="dica">Não possui conta? <a href="cadastro.php">Criar conta</a></p>
      </form>
    </section>
  </main>
</body>

</html>
