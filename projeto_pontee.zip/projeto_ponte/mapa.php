<?php
session_start();
$logado = !empty($_SESSION['logado']);
$nome = $_SESSION['nome_usuario'] ?? '';
$pagina = 'mapa.php';

$categorias = ['Comércio', 'Educação', 'Saúde', 'Órgão Público', 'Via Pública', 'Lazer', 'Outro'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mapa de acessibilidade | Ponte</title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/mapa.css">
</head>
<body>

<header>
  <div class="acesso">
    <?php if ($logado): ?>
      <span class="usuario"><?= htmlspecialchars($nome, ENT_QUOTES, 'UTF-8') ?></span>
      <a href="logout.php">Sair</a>
    <?php else: ?>
      <a href="login.php">Entrar</a>
      <a href="cadastro.php">Cadastrar</a>
    <?php endif; ?>
  </div>

  <h1>Mapa de acessibilidade</h1>
  <p class="subtitulo">Veja quais lugares são acessíveis antes de sair de casa.</p>

  <?php include('menu.php'); ?>
</header>

<main>

  <section class="filtros">
    <label for="filtro-categoria">Filtrar por categoria</label>
    <select id="filtro-categoria">
      <option value="">Todas</option>
      <?php foreach ($categorias as $c): ?>
        <option><?= $c ?></option>
      <?php endforeach; ?>
    </select>
  </section>

  <div class="mapa-area">
    <div id="mapa"></div>

    <section class="lista" aria-labelledby="titulo-lista">
      <h2 id="titulo-lista">Locais <span id="contador"></span></h2>
      <ul id="lista-locais"></ul>
    </section>
  </div>

  <p class="legenda">
    <span class="bolinha boa"></span> nota 4 ou mais
    <span class="bolinha media"></span> de 2,5 a 3,9
    <span class="bolinha ruim"></span> abaixo de 2,5
    <span class="bolinha sem"></span> sem avaliações
  </p>

  <?php if ($logado): ?>
    <div class="formularios">

      <section class="cartao">
        <h2>Cadastrar um local</h2>
        <p class="dica">Primeiro clique no mapa para marcar onde fica o local.</p>

        <form id="form-local">
          <label for="nome_local">Nome do local</label>
          <input type="text" id="nome_local" name="nome_local" maxlength="100" required>

          <label for="categoria_local">Categoria</label>
          <select id="categoria_local" name="categoria_local" required>
            <option value="">Escolha a categoria</option>
            <?php foreach ($categorias as $c): ?>
              <option><?= $c ?></option>
            <?php endforeach; ?>
          </select>

          <label for="rua_endereco">Rua</label>
          <input type="text" id="rua_endereco" name="rua_endereco" maxlength="60" required>

          <label for="num_endereco">Número</label>
          <input type="text" id="num_endereco" name="num_endereco" maxlength="10" required>

          <label for="bairro_endereco">Bairro</label>
          <input type="text" id="bairro_endereco" name="bairro_endereco" maxlength="60" required>

          <label for="complemento_endereco">Complemento (opcional)</label>
          <input type="text" id="complemento_endereco" name="complemento_endereco" maxlength="50">

          <p id="ponto-escolhido" class="dica">Nenhum ponto marcado no mapa ainda.</p>

          <button type="submit">Cadastrar local</button>
          <p id="msg-local" class="mensagem" role="status"></p>
        </form>
      </section>

  

       

    </div>
  <?php else: ?>
    <p class="aviso">
      <a href="login.php">Entre na sua conta</a> para cadastrar e avaliar locais.
    </p>
  <?php endif; ?>

</main>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="js/mapa.js"></script>
</body>
</html>
