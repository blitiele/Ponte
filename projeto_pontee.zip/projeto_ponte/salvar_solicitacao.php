<?php
    if (session_id() == "") {
        session_start();
    }

    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION["logado"])) {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Entre na sua conta para fazer uma solicitação."
        ]);
        exit;
    }

    $dados = json_decode(
        file_get_contents("php://input"),
        true
    );

    $item = isset($dados["item"]) ? $dados["item"] : "";
    $urgencia = isset($dados["urgencia"]) ? $dados["urgencia"] : "";
    $descricao = isset($dados["descricao"]) ? trim($dados["descricao"]) : "";
    $codUsuario = $_SESSION["cod_usuario"];

    $itens = ["Dinheiro", "Alimento", "Vestuário", "Equipamento", "Outro"];
    $urgencias = ["Baixa", "Média", "Alta"];

    $erro = "";

    if (!in_array($item, $itens)) {
        $erro = "Escolha o tipo do que você precisa.";
    }
    else if (!in_array($urgencia, $urgencias)) {
        $erro = "Escolha a urgência.";
    }
    else if ($descricao == "") {
        $erro = "Descreva o que você precisa.";
    }

    if ($erro != "") {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => $erro
        ]);
        exit;
    }

    include('conexao.php');

    $descricao = $conn->real_escape_string($descricao);

    $sql = "SELECT MAX(id_solicitacao) AS ultimo FROM solicitacao";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $id = str_pad($row["ultimo"] + 1, 4, "0", STR_PAD_LEFT);

    // toda solicitação nova começa "Aberta", com a data de hoje
    $sql = "INSERT INTO solicitacao (id_solicitacao, cod_usuario, item_solicitado, descricao_solicitacao,
                                     urgencia_solicitacao, data_solicitacao, situacao_solicitacao)
            VALUES ('$id', '$codUsuario', '$item', '$descricao', '$urgencia', CURDATE(), 'Aberta')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode([
            "sucesso" => true,
            "mensagem" => "Solicitação enviada! Ela já aparece na lista."
        ]);
    }
    else {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Não foi possível enviar a solicitação. Tente novamente."
        ]);
    }

    $conn->close();
?>
