<?php
    include('conexao.php');

    header('Content-Type: application/json; charset=utf-8');

    // filtro opcional: listar_avaliacoes.php?id_local=000003
    $idLocal = isset($_GET["id_local"]) ? $_GET["id_local"] : "";
    $idLocal = $conn->real_escape_string($idLocal);

    $sql = "SELECT a.id_avaliacao, a.nota, a.descricao, a.data_avaliacao,
                   l.nome_local, u.nome_usuario
            FROM avaliacao a
            JOIN locais l ON l.id_local = a.id_local
            JOIN usuario u ON u.cod_usuario = a.cod_usuario";

    if ($idLocal != "") {
        $sql = $sql . " WHERE a.id_local = '$idLocal'";
    }

    $sql = $sql . " ORDER BY a.data_avaliacao DESC, a.id_avaliacao DESC";

    $result = $conn->query($sql);

    $avaliacoes = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $avaliacoes[] = [
                "id" => $row["id_avaliacao"],
                "local" => $row["nome_local"],
                "nota" => (float) $row["nota"],
                "descricao" => $row["descricao"],
                "data" => date("d/m/Y", strtotime($row["data_avaliacao"])),
                "autor" => $row["nome_usuario"]
            ];
        }
    }

    $conn->close();

    echo json_encode($avaliacoes);
?>
