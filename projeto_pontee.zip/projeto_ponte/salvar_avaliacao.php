<?php
    if (session_id() == "") {
        session_start();
    }

    header('Content-Type: application/json; charset=utf-8');

    // precisa estar logado
    if (!isset($_SESSION["logado"])) {
        echo json_encode([
            "ok" => false,
            "mensagem" => "Entre na sua conta para avaliar um local."
        ]);
        exit;
    }

    // a página de Avaliações manda os dados em JSON (php://input)
    // o mapa manda como formulário (FormData), aí os dados chegam em $_POST
    $dados = json_decode(file_get_contents("php://input"), true);
    if ($dados == null) {
        $dados = $_POST;
    }

    $idLocal = isset($dados["id_local"]) ? trim($dados["id_local"]) : "";
    $nota = isset($dados["nota"]) ? $dados["nota"] : "";
    $descricao = isset($dados["descricao"]) ? trim($dados["descricao"]) : "";
    $codUsuario = $_SESSION["cod_usuario"];

    // validação da nota (0 a 5)
    if (!is_numeric($nota) || $nota < 0 || $nota > 5) {
        echo json_encode([
            "ok" => false,
            "mensagem" => "Escolha uma nota de 0 a 5."
        ]);
        exit;
    }

    // a descrição é obrigatória (é ela que explica o problema denunciado)
    if (strlen($descricao) < 10) {
        echo json_encode([
            "ok" => false,
            "mensagem" => "Descreva o problema com pelo menos 10 caracteres."
        ]);
        exit;
    }

    include('conexao.php');

    $idLocal = $conn->real_escape_string($idLocal);
    $descricao = $conn->real_escape_string($descricao);

    // 1) confere se o local existe e pega o nome dele
    $sql = "SELECT nome_local FROM locais WHERE id_local = '$idLocal'";
    $result = $conn->query($sql);

    if ($result->num_rows == 0) {
        echo json_encode([
            "ok" => false,
            "mensagem" => "Escolha um local da lista."
        ]);
        $conn->close();
        exit;
    }

    $row = $result->fetch_assoc();
    $nomeLocal = $row["nome_local"];

    // 2) descobre o próximo id da avaliação (0001, 0002, ...)
    $sql = "SELECT MAX(id_avaliacao) AS ultimo FROM avaliacao";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $id = str_pad($row["ultimo"] + 1, 4, "0", STR_PAD_LEFT);

    // 3) salva a avaliação
    $sql = "INSERT INTO avaliacao (id_avaliacao, nota, descricao, data_avaliacao, cod_usuario, id_local)
            VALUES ('$id', $nota, '$descricao', CURDATE(), '$codUsuario', '$idLocal')";

    if ($conn->query($sql) === TRUE) {

        // 4) atualiza a nota média do local
        $sql = "UPDATE locais
                SET nota_acessibilidade = (SELECT ROUND(AVG(nota), 2) FROM avaliacao WHERE id_local = '$idLocal')
                WHERE id_local = '$idLocal'";
        $conn->query($sql);

        echo json_encode([
            "ok" => true,
            "mensagem" => "Denúncia de " . $nomeLocal . " enviada. Obrigado!"
        ]);
    }
    else {
        echo json_encode([
            "ok" => false,
            "mensagem" => "Não foi possível salvar a avaliação agora. Tente novamente."
        ]);
    }

    $conn->close();
?>
