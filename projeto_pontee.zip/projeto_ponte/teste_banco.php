<?php
    // ============================================================
    // PÁGINA DE DIAGNÓSTICO DO BANCO
    // Abra: http://localhost/projeto_ponte/teste_banco.php
    // Depois que tudo estiver funcionando, pode apagar este arquivo.
    // ============================================================

    if (session_id() == "") {
        session_start();
    }

    // conta quantas vezes a página foi aberta (para testar se a sessão funciona)
    if (isset($_SESSION["teste_visitas"])) {
        $_SESSION["teste_visitas"] = $_SESSION["teste_visitas"] + 1;
    } else {
        $_SESSION["teste_visitas"] = 1;
    }

    mysqli_report(MYSQLI_REPORT_OFF);
    $conn = new mysqli("localhost", "root", "", "ponte");
    $erroConexao = $conn->connect_error;

    function ok($texto) {
        echo "<p class='ok'>✔ $texto</p>";
    }
    function erro($texto) {
        echo "<p class='erro'>✘ $texto</p>";
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Teste do banco | Ponte</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 900px; margin: 2rem auto; padding: 0 1rem; color: #0f322b; }
    h2 { margin-top: 2rem; border-bottom: 2px solid #c9d7d3; padding-bottom: .3rem; }
    .ok { color: #0d5a34; font-weight: 600; }
    .erro { color: #9b1c1c; font-weight: 600; background: #fadede; padding: .5rem .8rem; border-radius: 6px; }
    table { border-collapse: collapse; width: 100%; margin-top: .5rem; }
    th, td { border: 1px solid #c9d7d3; padding: .4rem .6rem; text-align: left; }
    th { background: #eaf0ee; }
    code { background: #eaf0ee; padding: .1rem .3rem; border-radius: 4px; }
    input, button { font: inherit; padding: .4rem .6rem; margin: .2rem 0; }
  </style>
</head>
<body>

<h1>Diagnóstico do banco de dados</h1>

<!-- ==================== 1. CONEXÃO ==================== -->
<h2>1. Conexão</h2>
<?php
    if ($erroConexao) {
        erro("Não conectou: " . $erroConexao);
        echo "<p>Confira se o MySQL está ligado no painel do XAMPP e se o banco <code>ponte</code> existe
              (rode o <code>projeto_ponte.sql</code>). Se o seu MySQL tem senha, coloque ela no
              <code>conexao.php</code>.</p>";
        echo "</body></html>";
        exit;
    }
    ok("Conectou no banco <code>ponte</code>.");
?>

<!-- ==================== 2. COLUNA SENHA ==================== -->
<h2>2. Tabela usuario</h2>
<?php
    $result = $conn->query("SHOW COLUMNS FROM usuario LIKE 'senha'");
    $row = $result->fetch_assoc();
    $tipoSenha = $row["Type"];

    if ($tipoSenha == "varchar(255)") {
        ok("Coluna senha: <code>$tipoSenha</code> (certo).");
    } else {
        erro("Coluna senha: <code>$tipoSenha</code>. Precisa ser varchar(255). Rode o <code>consertar_login.sql</code>.");
    }

    $result = $conn->query("SHOW COLUMNS FROM usuario LIKE 'telefone'");
    $row = $result->fetch_assoc();

    if ($row["Null"] == "YES") {
        ok("Telefone é opcional (certo).");
    } else {
        erro("Telefone é obrigatório, então o cadastro do site falha. Rode o <code>consertar_login.sql</code>.");
    }
?>

<!-- ==================== 3. USUÁRIOS ==================== -->
<h2>3. Usuários cadastrados</h2>
<p>Na tela de login, digite o que aparece na coluna <b>Login</b> (igualzinho, com espaço e maiúsculas) ou o e-mail.</p>
<table>
  <tr><th>Código</th><th>Login</th><th>E-mail</th><th>Senha no banco</th></tr>
  <?php
      $result = $conn->query("SELECT cod_usuario, nome_usuario, email, senha FROM usuario ORDER BY cod_usuario");
      $senhasQuebradas = 0;

      while ($row = $result->fetch_assoc()) {
          $senha = $row["senha"];

          if (substr($senha, 0, 1) != "$") {
              $situacao = "<span class='ok'>texto puro (funciona)</span>";
          } else if (strlen($senha) == 60) {
              $situacao = "<span class='ok'>criptografada (funciona)</span>";
          } else {
              $situacao = "<span class='erro'>CORTADA, tem " . strlen($senha) . " caracteres (não funciona)</span>";
              $senhasQuebradas++;
          }

          echo "<tr>";
          echo "<td>" . $row["cod_usuario"] . "</td>";
          echo "<td><code>" . htmlspecialchars($row["nome_usuario"]) . "</code></td>";
          echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
          echo "<td>$situacao</td>";
          echo "</tr>";
      }
  ?>
</table>
<?php
    if ($senhasQuebradas > 0) {
        erro("$senhasQuebradas conta(s) com a senha cortada. Rode o <code>consertar_login.sql</code>: essas contas passam a ter a senha <code>123456</code>.");
    }
?>

<!-- ==================== 4. SESSÃO ==================== -->
<h2>4. Sessão</h2>
<?php
    if ($_SESSION["teste_visitas"] > 1) {
        ok("A sessão está funcionando (página aberta " . $_SESSION["teste_visitas"] . " vezes).");
    } else {
        echo "<p>Atualize a página (F5). Se o número abaixo não aumentar, a sessão não está sendo salva.</p>";
        echo "<p>Vezes que a página foi aberta: <b>" . $_SESSION["teste_visitas"] . "</b></p>";
    }
?>

<!-- ==================== 5. TESTAR LOGIN ==================== -->
<h2>5. Testar um login</h2>
<p>Isso só testa, não faz login de verdade.</p>
<form method="post">
  <input type="text" name="teste_login" placeholder="Login ou e-mail" required>
  <input type="password" name="teste_senha" placeholder="Senha" required>
  <button type="submit">Testar</button>
</form>
<?php
    if (isset($_POST["teste_login"])) {
        $login = $conn->real_escape_string(trim($_POST["teste_login"]));
        $senha = $_POST["teste_senha"];

        $sql = "SELECT nome_usuario, senha FROM usuario WHERE nome_usuario = '$login' OR email = '$login'";
        $result = $conn->query($sql);

        if ($result->num_rows == 0) {
            erro("Nenhum usuário com esse login ou e-mail. Confira a tabela acima.");
        } else {
            $row = $result->fetch_assoc();

            if (password_verify($senha, $row["senha"]) || $senha == $row["senha"]) {
                ok("Login e senha certos para <code>" . htmlspecialchars($row["nome_usuario"]) . "</code>. O login.php deve funcionar.");
            } else {
                erro("O usuário existe, mas a senha não confere.");
            }
        }
    }

    $conn->close();
?>

</body>
</html>
