<?php
    if (session_id() == "") {
        session_start();
    }

    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION["logado"])) {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Entre na sua conta para escrever um artigo."
        ]);
        exit;
    }

    $dados = json_decode(
        file_get_contents("php://input"),
        true
    );

    $titulo = isset($dados["titulo"]) ? trim($dados["titulo"]) : "";
    $conteudo = isset($dados["conteudo"]) ? trim($dados["conteudo"]) : "";
    $situacao = isset($dados["situacao"]) ? $dados["situacao"] : "";
    $codUsuario = $_SESSION["cod_usuario"];

    $erro = "";

    if (strlen($titulo) < 5) {
        $erro = "O título precisa ter pelo menos 5 caracteres.";
    }
    else if (mb_strlen($titulo) > 100) {
        $erro = "O título pode ter até 100 caracteres.";
    }
    else if (strlen($conteudo) < 50) {
        $erro = "O texto precisa ter pelo menos 50 caracteres.";
    }
    else if ($situacao != "Publicado" && $situacao != "Rascunho") {
        $erro = "Escolha se quer publicar ou guardar como rascunho.";
    }

    if ($erro != "") {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => $erro
        ]);
        exit;
    }

    include('conexao.php');

    $titulo = $conn->real_escape_string($titulo);
    $conteudo = $conn->real_escape_string($conteudo);

    $sql = "SELECT MAX(id_artigo) AS ultimo FROM artigo";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $id = str_pad($row["ultimo"] + 1, 4, "0", STR_PAD_LEFT);

    $sql = "INSERT INTO artigo (id_artigo, cod_usuario, titulo_artigo, conteudo_artigo, data_publicacao, situacao_artigo)
            VALUES ('$id', '$codUsuario', '$titulo', '$conteudo', CURDATE(), '$situacao')";

    if ($conn->query($sql) === TRUE) {

        if ($situacao == "Publicado") {
            $mensagem = "Artigo publicado!";
        }
        else {
            $mensagem = "Rascunho guardado. Ele aparece em \"Meus artigos\".";
        }

        echo json_encode([
            "sucesso" => true,
            "mensagem" => $mensagem,
            "id" => $id
        ]);
    }
    else {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Não foi possível salvar o artigo. Tente novamente."
        ]);
    }

    $conn->close();
?>
