<?php
    if (session_id() == "") {
        session_start();
    }
    $logado = isset($_SESSION["logado"]);
    $nome = isset($_SESSION["nome_usuario"]) ? $_SESSION["nome_usuario"] : "";
    $pagina = "doacoes_solicitacoes.php";

    // mesmos valores do enum no banco (tabelas solicitacao e doacao)
    $itens = ["Dinheiro", "Alimento", "Vestuário", "Equipamento", "Outro"];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Doações e solicitações | Ponte</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700&display=swap">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/paginas.css">
</head>
<body>

<header>
  <div class="acesso">
    <?php if ($logado) { ?>
      <span class="usuario"><?=htmlspecialchars($nome)?></span>
      <a href="logout.php">Sair</a>
    <?php } else { ?>
      <a href="login.php">Entrar</a>
      <a href="cadastro.php">Cadastrar</a>
    <?php } ?>
  </div>

  <h1>Doações e solicitações</h1>
  <p class="subtitulo">Peça o que você precisa ou ajude quem está precisando.</p>

  <?php include('menu.php'); ?>
</header>

<main>

  <!-- ===================== FORMULÁRIOS ===================== -->
  <section class="blocos">

    <article class="bloco">
      <h2>Fazer uma solicitação</h2>

      <?php if ($logado) { ?>
        <form id="form-solicitacao">
          <label for="item_solicitado">O que você precisa?</label>
          <select id="item_solicitado" required>
            <option value="">Escolha o tipo</option>
            <?php foreach ($itens as $item) { ?>
              <option><?=$item?></option>
            <?php } ?>
          </select>

          <label for="urgencia">Urgência</label>
          <select id="urgencia" required>
            <option value="">Escolha a urgência</option>
            <option>Baixa</option>
            <option>Média</option>
            <option>Alta</option>
          </select>

          <label for="descricao_solicitacao">Descrição</label>
          <textarea id="descricao_solicitacao" maxlength="300" required
            placeholder="Ex.: Cadeira de rodas, a minha está com a roda quebrada."></textarea>

          <button type="submit">Enviar solicitação</button>
          <p id="msg-solicitacao" class="mensagem" role="status"></p>
        </form>
      <?php } else { ?>
        <p class="aviso"><a href="login.php">Entre na sua conta</a> para fazer uma solicitação.</p>
      <?php } ?>
    </article>

    <article class="bloco" id="bloco-doacao">
      <h2>Fazer uma doação</h2>

      <?php if ($logado) { ?>
        <form id="form-doacao">
          <label for="id_solicitacao">Para quem?</label>
          <select id="id_solicitacao">
            <option value="">Doação geral (sem solicitação)</option>
          </select>
          <p class="dica">Você também pode clicar em "Quero ajudar" numa solicitação da lista.</p>

          <label for="tipo_item">O que você vai doar?</label>
          <select id="tipo_item" required>
            <option value="">Escolha o tipo</option>
            <?php foreach ($itens as $item) { ?>
              <option><?=$item?></option>
            <?php } ?>
          </select>

          <label for="quantidade">Quantidade (ou valor em R$, se for dinheiro)</label>
          <input type="text" id="quantidade" inputmode="decimal" required placeholder="Ex.: 2 ou 50,00">

          <label for="descricao_doacao">Descrição (opcional)</label>
          <textarea id="descricao_doacao" maxlength="300"
            placeholder="Ex.: Cadeira de rodas usada, em bom estado."></textarea>

          <button type="submit">Registrar doação</button>
          <p id="msg-doacao" class="mensagem" role="status"></p>
        </form>
      <?php } else { ?>
        <p class="aviso"><a href="login.php">Entre na sua conta</a> para registrar uma doação.</p>
      <?php } ?>
    </article>

  </section>

  <!-- ===================== LISTAS ===================== -->
  <section class="blocos">

    <article class="bloco">
      <h2>Solicitações</h2>

      <label for="filtro-solicitacao">Mostrar</label>
      <select id="filtro-solicitacao" class="filtro">
        <option value="abertas">Abertas e em andamento</option>
        <option value="">Todas</option>
      </select>

      <ul id="lista-solicitacoes" class="lista-cartoes"></ul>
    </article>

    <article class="bloco">
      <h2>Doações registradas</h2>
      <ul id="lista-doacoes" class="lista-cartoes"></ul>
    </article>

  </section>

</main>

<script>
  // o PHP avisa o JavaScript se a pessoa está logada (para mostrar o botão "Quero ajudar")
  const logado = <?=$logado ? "true" : "false"?>;
</script>
<script src="js/doacoes.js"></script>
</body>
</html>
