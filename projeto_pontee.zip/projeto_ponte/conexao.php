<?php
    // faz o mysqli devolver FALSE quando dá erro (em vez de travar a página),
    // assim o "if (...) === TRUE { } else { }" funciona como nos slides
    mysqli_report(MYSQLI_REPORT_OFF);

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ponte";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // para os acentos (ç, ã, é...) virem certos do banco
    $conn->set_charset("utf8mb4");
?>
