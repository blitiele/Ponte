USE ponte;

ALTER TABLE usuario MODIFY senha VARCHAR(255) NOT NULL;

ALTER TABLE usuario MODIFY telefone VARCHAR(20) NULL;

ALTER TABLE usuario ADD UNIQUE (nome_usuario);
