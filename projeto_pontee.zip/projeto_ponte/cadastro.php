<?php
    if (session_id() == "") {
        session_start();
    }

    // se já está logado, volta para o início
    if (isset($_SESSION["logado"])) {
        header("Location: index.php");
        exit;
    }

    $erro = "";

    $login = isset($_POST["login"]) ? trim($_POST["login"]) : "";
    $senha = isset($_POST["senha"]) ? $_POST["senha"] : "";
    $confirma = isset($_POST["confirma"]) ? $_POST["confirma"] : "";

    if (isset($_POST["btnCadastrar"])) {

        if (strlen($login) < 3 || strlen($login) > 50) {
            $erro = "O login deve ter de 3 a 50 caracteres.";
        }
        else if (strlen($senha) < 6) {
            $erro = "A senha deve ter pelo menos 6 caracteres.";
        }
        else if ($senha != $confirma) {
            $erro = "As senhas não são iguais.";
        }
        else {
            include('conexao.php');

            $loginSeguro = $conn->real_escape_string($login);

            // 1) verifica se o login já existe
            $sql = "SELECT cod_usuario FROM usuario WHERE nome_usuario = '$loginSeguro'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $erro = "Esse login já está em uso. Escolha outro.";
            }
            else {
                // 2) descobre o próximo código (000001, 000002, ...)
                $sql = "SELECT MAX(cod_usuario) AS ultimo FROM usuario";
                $result = $conn->query($sql);
                $row = $result->fetch_assoc();
                $cod = str_pad($row["ultimo"] + 1, 6, "0", STR_PAD_LEFT);

                // 3) guarda a senha criptografada
                $hash = password_hash($senha, PASSWORD_DEFAULT);

                $sql = "INSERT INTO usuario (cod_usuario, nome_usuario, senha) VALUES ('$cod', '$loginSeguro', '$hash')";

                if ($conn->query($sql) === TRUE) {

                    // 4) confere se a senha foi salva inteira
                    //    (se a coluna senha for pequena, o banco corta a senha e o login nunca funciona)
                    $sql = "SELECT senha FROM usuario WHERE cod_usuario = '$cod'";
                    $result = $conn->query($sql);
                    $row = $result->fetch_assoc();

                    if (password_verify($senha, $row["senha"])) {
                        $_SESSION["aviso_login"] = "Conta criada! Entre com seus dados.";
                        $conn->close();
                        header("Location: login.php");
                        exit;
                    }
                    else {
                        $conn->query("DELETE FROM usuario WHERE cod_usuario = '$cod'");
                        $erro = "O banco de dados precisa ser atualizado: rode o arquivo consertar_login.sql no phpMyAdmin.";
                    }
                }
                else {
                    $erro = "Não foi possível criar a conta. Se continuar, rode o arquivo consertar_login.sql no phpMyAdmin.";
                }
            }

            $conn->close();
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Criar conta · PONTE</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700&display=swap">
  <link rel="stylesheet" href="logcad.css">
</head>

<body>
  <main class="login">
    <section class="login__marca">
      <h1>PONTE</h1>
      <br>
    </section>

    <section class="login__acesso">
      <form class="login__form" method="post" action="cadastro.php">
        <h2>Criar conta</h2>

        <?php if ($erro != "") { ?>
          <p class="alerta alerta--erro" role="alert"><?=$erro?></p>
        <?php } ?>

        <div class="campo">
          <label for="login">Login</label>
          <input type="text" id="login" name="login" autocomplete="username" maxlength="50"
            value="<?=htmlspecialchars($login)?>" required autofocus>
        </div>

        <div class="campo">
          <label for="senha">Senha</label>
          <input type="password" id="senha" name="senha" autocomplete="new-password" minlength="6" required>
        </div>

        <div class="campo">
          <label for="confirma">Confirmar senha</label>
          <input type="password" id="confirma" name="confirma" autocomplete="new-password" minlength="6" required>
        </div>

        <button type="submit" name="btnCadastrar" class="botao">Criar conta</button>

        <p class="dica">Já tem conta? <a href="login.php">Entrar</a></p>
      </form>
    </section>
  </main>
</body>

</html>
