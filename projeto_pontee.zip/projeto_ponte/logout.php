<?php
    if (session_id() == "") {
        session_start();
    }

    // apaga os dados da sessão e encerra
    session_unset();
    session_destroy();

    header("Location: index.php");
?>
