<?php
    include('conexao.php');

    header('Content-Type: application/json; charset=utf-8');

    $resposta = [];

    // 1) lê todos os locais, com a média e o total de avaliações de cada um
    $sql = "SELECT l.id_local, l.nome_local, l.latitude, l.longitude,
                   l.rua_endereco, l.num_endereco, l.bairro_endereco, l.complemento_endereco,
                   l.categoria_local,
                   (SELECT AVG(a.nota) FROM avaliacao a WHERE a.id_local = l.id_local) AS media,
                   (SELECT COUNT(*) FROM avaliacao a WHERE a.id_local = l.id_local) AS total_avaliacoes
            FROM locais l
            ORDER BY l.nome_local";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            $media = null;
            if ($row["media"] != null) {
                $media = round($row["media"], 1);
            }

            // usa o id do local como chave para achar ele depois
            $resposta[$row["id_local"]] = [
                "id" => $row["id_local"],
                "nome" => $row["nome_local"],
                "lat" => (float) $row["latitude"],
                "lng" => (float) $row["longitude"],
                "rua" => $row["rua_endereco"],
                "numero" => $row["num_endereco"],
                "bairro" => $row["bairro_endereco"],
                "complemento" => $row["complemento_endereco"],
                "categoria" => $row["categoria_local"],
                "media" => $media,
                "totalAvaliacoes" => (int) $row["total_avaliacoes"],
                "denuncias" => []
            ];
        }
    }

    // 2) lê as avaliações (nota + descrição) e coloca cada uma dentro do seu local.
    //    O mapa mostra elas na parte "Denúncias" do balão de cada local.
    $sql = "SELECT id_local, nota, descricao, data_avaliacao
            FROM avaliacao
            WHERE descricao IS NOT NULL AND descricao <> ''
            ORDER BY data_avaliacao DESC, id_avaliacao DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            $idLocal = $row["id_local"];

            if (isset($resposta[$idLocal])) {
                $resposta[$idLocal]["denuncias"][] = [
                    "descricao" => $row["descricao"],
                    "situacao" => "nota " . str_replace(".", ",", (float) $row["nota"]),
                    "data" => date("d/m/Y", strtotime($row["data_avaliacao"]))
                ];
            }
        }
    }

    $conn->close();

    // array_values tira as chaves e devolve uma lista [ {...}, {...} ]
    echo json_encode(array_values($resposta));
?>
