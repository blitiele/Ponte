<?php
    // Página que mostra UM artigo inteiro: artigo.php?id=0001
    if (session_id() == "") {
        session_start();
    }
    $logado = isset($_SESSION["logado"]);
    $nome = isset($_SESSION["nome_usuario"]) ? $_SESSION["nome_usuario"] : "";
    $codUsuario = isset($_SESSION["cod_usuario"]) ? $_SESSION["cod_usuario"] : "";
    $pagina = "artigos.php"; // deixa "Artigos" marcado no menu

    include('conexao.php');

    $id = isset($_GET["id"]) ? $_GET["id"] : "";
    $id = $conn->real_escape_string($id);

    $sql = "SELECT a.id_artigo, a.titulo_artigo, a.conteudo_artigo, a.data_publicacao,
                   a.situacao_artigo, a.cod_usuario, u.nome_usuario
            FROM artigo a
            JOIN usuario u ON u.cod_usuario = a.cod_usuario
            WHERE a.id_artigo = '$id'";
    $result = $conn->query($sql);

    $artigo = null;

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // publicado: todo mundo vê | rascunho: só quem escreveu vê
        if ($row["situacao_artigo"] == "Publicado" ||
           ($row["situacao_artigo"] == "Rascunho" && $row["cod_usuario"] == $codUsuario)) {
            $artigo = $row;
        }
    }

    $conn->close();

    // separa o texto em parágrafos (cada linha em branco = novo parágrafo)
    $paragrafos = [];

    if ($artigo != null) {
        $texto = str_replace("\r\n", "\n", $artigo["conteudo_artigo"]);
        $partes = explode("\n\n", $texto);

        foreach ($partes as $parte) {
            $parte = trim($parte);
            if ($parte != "") {
                $paragrafos[] = $parte;
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?=$artigo != null ? htmlspecialchars($artigo["titulo_artigo"]) : "Artigo não encontrado"?> | Ponte</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700&display=swap">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/paginas.css">
</head>
<body>

<header>
  <div class="acesso">
    <?php if ($logado) { ?>
      <span class="usuario"><?=htmlspecialchars($nome)?></span>
      <a href="logout.php">Sair</a>
    <?php } else { ?>
      <a href="login.php">Entrar</a>
      <a href="cadastro.php">Cadastrar</a>
    <?php } ?>
  </div>

  <h1>Artigos</h1>

  <?php include('menu.php'); ?>
</header>

<main>
  <section class="blocos">
    <article class="bloco leitura">

      <p><a href="artigos.php" class="voltar">← Voltar para os artigos</a></p>

      <?php if ($artigo == null) { ?>

        <h2>Artigo não encontrado</h2>
        <p>Esse artigo não existe ou ainda não foi publicado.</p>

      <?php } else { ?>

        <h2><?=htmlspecialchars($artigo["titulo_artigo"])?></h2>

        <p class="detalhes">
          Por <?=htmlspecialchars($artigo["nome_usuario"])?>
          · <?=date("d/m/Y", strtotime($artigo["data_publicacao"]))?>
          <?php if ($artigo["situacao_artigo"] == "Rascunho") { ?>
            · <span class="etiqueta amarelo">Rascunho</span>
          <?php } ?>
        </p>

        <?php foreach ($paragrafos as $paragrafo) { ?>
          <p class="texto-artigo"><?=nl2br(htmlspecialchars($paragrafo))?></p>
        <?php } ?>

      <?php } ?>

    </article>
  </section>
</main>

</body>
</html>
