-- Rode este arquivo no phpMyAdmin (aba SQL) se o login não funciona.
-- Ele NÃO apaga nada do banco.
USE ponte;

-- 1) aumenta a coluna da senha (a senha criptografada tem 60 caracteres)
ALTER TABLE usuario MODIFY senha VARCHAR(255) NOT NULL;

-- 2) deixa o telefone opcional (o cadastro do site não pede telefone)
ALTER TABLE usuario MODIFY telefone VARCHAR(20) NULL;

-- 3) contas criadas quando a coluna era pequena ficaram com a senha cortada.
--    Elas passam a ter a senha 123456 (troque depois, se quiser).
UPDATE usuario SET senha = '123456'
WHERE senha LIKE '$%' AND CHAR_LENGTH(senha) < 60;

-- 4) devolve as senhas originais dos usuários de exemplo
UPDATE usuario SET senha = 'joni@20'   WHERE cod_usuario = '000001';
UPDATE usuario SET senha = '9091silva' WHERE cod_usuario = '000002';
UPDATE usuario SET senha = 'Cami$2025' WHERE cod_usuario = '000003';
UPDATE usuario SET senha = 'Diego@789' WHERE cod_usuario = '000004';
UPDATE usuario SET senha = 'Duda!4567' WHERE cod_usuario = '000005';
