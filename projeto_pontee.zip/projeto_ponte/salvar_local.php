<?php
    if (session_id() == "") {
        session_start();
    }

    header('Content-Type: application/json; charset=utf-8');

    // precisa estar logado
    if (!isset($_SESSION["logado"])) {
        echo json_encode([
            "ok" => false,
            "mensagem" => "Entre na sua conta para cadastrar um local."
        ]);
        exit;
    }

    $nome = isset($_POST["nome_local"]) ? trim($_POST["nome_local"]) : "";
    $categoria = isset($_POST["categoria_local"]) ? $_POST["categoria_local"] : "";
    $rua = isset($_POST["rua_endereco"]) ? trim($_POST["rua_endereco"]) : "";
    $numero = isset($_POST["num_endereco"]) ? trim($_POST["num_endereco"]) : "";
    $bairro = isset($_POST["bairro_endereco"]) ? trim($_POST["bairro_endereco"]) : "";
    $complemento = isset($_POST["complemento_endereco"]) ? trim($_POST["complemento_endereco"]) : "";
    $lat = isset($_POST["latitude"]) ? $_POST["latitude"] : "";
    $lng = isset($_POST["longitude"]) ? $_POST["longitude"] : "";

    $categorias = ["Comércio", "Educação", "Saúde", "Órgão Público", "Via Pública", "Lazer", "Outro"];

    // validações
    $erro = "";

    if ($nome == "") {
        $erro = "Informe o nome do local.";
    }
    else if (!in_array($categoria, $categorias)) {
        $erro = "Escolha uma categoria válida.";
    }
    else if ($rua == "") {
        $erro = "Informe a rua.";
    }
    else if ($numero == "") {
        $erro = "Informe o número.";
    }
    else if ($bairro == "") {
        $erro = "Informe o bairro.";
    }
    else if (!is_numeric($lat) || !is_numeric($lng)) {
        $erro = "Clique no mapa para marcar onde fica o local.";
    }

    if ($erro != "") {
        echo json_encode([
            "ok" => false,
            "mensagem" => $erro
        ]);
        exit;
    }

    include('conexao.php');

    // descobre o próximo id (000001, 000002, ...)
    $sql = "SELECT MAX(id_local) AS ultimo FROM locais";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $id = str_pad($row["ultimo"] + 1, 6, "0", STR_PAD_LEFT);

    // protege os textos antes de colocar no SQL
    $nome = $conn->real_escape_string($nome);
    $categoria = $conn->real_escape_string($categoria);
    $rua = $conn->real_escape_string($rua);
    $numero = $conn->real_escape_string($numero);
    $bairro = $conn->real_escape_string($bairro);
    $complemento = $conn->real_escape_string($complemento);
    $lat = round($lat, 6);
    $lng = round($lng, 6);

    $sql = "INSERT INTO locais (id_local, nome_local, latitude, longitude, rua_endereco,
                                num_endereco, bairro_endereco, complemento_endereco, categoria_local)
            VALUES ('$id', '$nome', $lat, $lng, '$rua', '$numero', '$bairro', '$complemento', '$categoria')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode([
            "ok" => true,
            "mensagem" => $_POST["nome_local"] . " foi cadastrado e já aparece no mapa."
        ]);
    }
    else {
        echo json_encode([
            "ok" => false,
            "mensagem" => "Não foi possível cadastrar agora. Tente novamente."
        ]);
    }

    $conn->close();
?>
