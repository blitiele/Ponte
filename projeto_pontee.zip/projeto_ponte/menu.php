<?php
    // Menu igual em todas as páginas.
    // Cada página cria a variável $pagina antes do include('menu.php'),
    // assim o link da página atual fica sublinhado.

    $menu = [
        "index.php" => "Início",
        "mapa.php" => "Mapa de acessibilidade",
        "avaliacoes_denuncias.php" => "Avaliações e denúncias",
        "artigos.php" => "Artigos",
        "doacoes_solicitacoes.php" => "Doações e solicitações"
    ];
?>
<nav aria-label="Menu principal">
  <ul>
    <?php foreach ($menu as $link => $texto) { ?>
      <?php if ($link == $pagina) { ?>
        <li><a href="<?=$link?>" aria-current="page"><?=$texto?></a></li>
      <?php } else { ?>
        <li><a href="<?=$link?>"><?=$texto?></a></li>
      <?php } ?>
    <?php } ?>
  </ul>
</nav>
