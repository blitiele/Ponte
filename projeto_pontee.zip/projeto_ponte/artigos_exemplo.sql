-- Artigos de exemplo para a página de Artigos.
-- Rode este arquivo no phpMyAdmin (aba SQL) se o seu banco já existe.
USE ponte;

insert into artigo (id_artigo, cod_usuario, titulo_artigo, conteudo_artigo, data_publicacao, situacao_artigo) values
('0001', '000003', 'O que é acessibilidade de verdade?',
'Acessibilidade não é só colocar uma rampa na entrada. É pensar em todas as pessoas que vão usar aquele espaço: quem usa cadeira de rodas, quem tem baixa visão, quem é surdo, quem tem deficiência intelectual e também idosos e gestantes.\n\nUm lugar acessível tem rampas com inclinação correta, piso tátil, banheiro adaptado, sinalização em braile e atendimento preparado. Quando falta uma dessas coisas, alguém fica de fora.\n\nPor isso é tão importante avaliar e denunciar os lugares aqui no Ponte: cada avaliação ajuda outra pessoa a decidir aonde ir.',
'2026-08-12', 'Publicado'),
('0002', '000001', 'Dicas para quem vai doar equipamentos',
'Cadeiras de rodas, andadores e muletas fazem muita diferença na vida de quem precisa. Antes de doar, confira se o equipamento está limpo e funcionando: rodas girando, freios segurando e nenhuma peça solta.\n\nSe possível, informe na descrição da doação o tamanho e o estado do equipamento. Isso ajuda a encontrar a pessoa certa mais rápido.\n\nE lembre: na página de Doações e solicitações você pode clicar em "Quero ajudar" para doar direto para quem pediu.',
'2026-09-03', 'Publicado'),
('0003', '000005', 'Piso tátil: para que serve?',
'O piso tátil é aquele piso com relevo que aparece em calçadas e estações. Ele guia pessoas cegas ou com baixa visão, que sentem o relevo com os pés ou com a bengala.\n\nExistem dois tipos: o direcional, com linhas retas, que mostra o caminho; e o de alerta, com bolinhas, que avisa sobre obstáculos, escadas ou mudanças de direção.\n\nQuando o piso tátil está quebrado ou leva direto para um poste, ele atrapalha mais do que ajuda. Se você vir isso, faça uma denúncia!',
'2026-10-20', 'Publicado');
