<?php
    if (session_id() == "") {
        session_start();
    }
    $logado = isset($_SESSION["logado"]);
    $nome = isset($_SESSION["nome_usuario"]) ? $_SESSION["nome_usuario"] : "";
    $pagina = "index.php";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ponte</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="css/style.css">

</head>
<body>

    <header>
  <div class="acesso">
    <?php if ($logado) { ?>
      <span class="usuario"><?=htmlspecialchars($nome)?></span>
      <a href="logout.php">Sair</a>
    <?php } else { ?>
      <a href="login.php">Entrar</a>
      <a href="cadastro.php">Cadastrar</a>
    <?php } ?>
  </div>

  <div class="marca">
  
    <h1>Ponte</h1>
  </div>

  <p class="subtitulo">Mais acessibilidade, mais possibilidades.</p>

  <?php include('menu.php'); ?>

</header>

<main>

 <section class="blocos">
  <article class="bloco">
    <a href="mapa.php">
    <img src="imagens/mapa.jpg" alt="Mapa de acessibilidade">
    <p>Saia de casa sabendo aonde ir: veja quais lugares são acessíveis antes de sair.</p>
    </a>
  </article>

  <article class="bloco">
    <a href="doacoes_solicitacoes.php">
    <img src="imagens/doacao.jpg" alt="Doações e solicitações">
    <p>Doe ou peça ajuda. Cada doação pode atender a necessidade de alguém.</p>
    </a>
  </article>

  <article class="bloco">
    <a href="avaliacoes_denuncias.php">
    <img src="imagens/denuncia.jpg" alt="Denúncias">
    <p>Denuncie e avalie estabelecimentos sem a acessibilidade devida e ajude a cobrar melhorias.</p>
    </a>
  </article>

  <article class="bloco">
    <a href="artigos.php">
    <img src="imagens/artigos.jpg" alt="Artigos">
    <p>Leia e escreva conteúdos sobre inclusão para a comunidade.</p>
    </a>
  </article>

</section>
  </main>
</body>
</html>
