drop database if exists ponte;
create database ponte;
use ponte;

create table usuario(
cod_usuario char(6) primary key not null,
nome_usuario varchar(100) not null unique,
telefone varchar(20) null,
senha varchar(255) not null,
email varchar(100) null unique
);

create table pessoa_fisica(
cod_usuario char(6) primary key not null,
cpf char(11) not null unique,
tipo_deficiencia enum('Física','Visual','Auditiva','Intelectual','Múltipla','Outra','Não se aplica') null,
tipo_usuario enum('PCD','Voluntário','Administrador') not null,
foreign key (cod_usuario) references usuario(cod_usuario)
);

create table instituicao(
cod_usuario char(6) primary key not null,
cnpj char(14) not null unique,
foreign key (cod_usuario) references usuario(cod_usuario)
);

create table locais(
id_local char(6) primary key not null,
nome_local varchar(100) not null,
longitude numeric(9,6) not null check (longitude >= -180 and longitude <= 180),
latitude numeric(9,6) not null check (latitude >= -90 and latitude <= 90),
rua_endereco varchar(60) not null,
bairro_endereco varchar(60) not null,
num_endereco varchar(10) not null,
complemento_endereco varchar(50) null,
categoria_local enum('Comércio','Educação','Saúde','Órgão Público','Via Pública','Lazer','Outro') not null,
nota_acessibilidade decimal(3,2) null check (nota_acessibilidade >= 0 and nota_acessibilidade <= 5)
);

create table avaliacao(
id_avaliacao char(4) primary key not null,
nota decimal(3,2) not null check (nota >= 0 and nota <= 5),
descricao varchar(500) null,
data_avaliacao date not null,
cod_usuario char(6) not null,
id_local char(6) not null,
foreign key (cod_usuario) references usuario(cod_usuario),
foreign key (id_local) references locais(id_local)
);

delimiter $$
create trigger checar_data_avaliacao
before insert on avaliacao
for each row
begin
  if new.data_avaliacao > curdate() then
    signal sqlstate '45000'
    set message_text = 'A data da avaliação não pode ser no futuro';
  end if;
end$$
delimiter ;

create table solicitacao(
id_solicitacao char(4) primary key not null,
cod_usuario char(6) not null,
item_solicitado enum('Dinheiro','Alimento','Vestuário','Equipamento','Outro') not null,
descricao_solicitacao varchar(300) not null,
urgencia_solicitacao enum('Baixa','Média','Alta') not null,
data_solicitacao date not null,
situacao_solicitacao enum('Aberta','Em andamento','Atendida','Cancelada') not null,
foreign key (cod_usuario) references usuario(cod_usuario)
);

delimiter $$
create trigger checar_data_solicitacao
before insert on solicitacao
for each row
begin
  if new.data_solicitacao > curdate() then
    signal sqlstate '45000'
    set message_text = 'A data da solicitação não pode ser no futuro';
  end if;
end$$
delimiter ;

create table doacao(
id_doacao char(4) primary key not null,
cod_usuario char(6) not null,
id_solicitacao char(4) null,
tipo_item enum('Dinheiro','Alimento','Vestuário','Equipamento','Outro') not null,
descricao_doacao varchar(300) null,
data_doacao date not null,
quantidade_doada decimal(10,2) not null check (quantidade_doada > 0),
situacao_doacao enum('Disponível','Reservada','Entregue') not null,
foreign key (cod_usuario) references usuario(cod_usuario),
foreign key (id_solicitacao) references solicitacao(id_solicitacao)
);

delimiter $$
create trigger checar_data_doacao
before insert on doacao
for each row
begin
  if new.data_doacao > curdate() then
    signal sqlstate '45000'
    set message_text = 'A data da doação não pode ser no futuro';
  end if;
end$$
delimiter ;

create table denuncia(
id_denuncia char(4) primary key not null,
cod_usuario char(6) not null,
id_local char(6) not null,
descricao_denuncia varchar(500) not null,
situacao_denuncia enum('Pendente','Em análise','Resolvida','Rejeitada') not null,
data_denuncia date not null,
foreign key (cod_usuario) references usuario(cod_usuario),
foreign key (id_local) references locais(id_local)
);

delimiter $$
create trigger checar_data_denuncia
before insert on denuncia
for each row
begin
  if new.data_denuncia > curdate() then
    signal sqlstate '45000'
    set message_text = 'A data da denúncia não pode ser no futuro';
  end if;
end$$
delimiter ;

create table artigo(
id_artigo char(4) primary key not null,
cod_usuario char(6) not null,
titulo_artigo varchar(100) not null,
conteudo_artigo text not null,
data_publicacao date not null,
situacao_artigo enum('Rascunho','Publicado','Removido') not null,
foreign key (cod_usuario) references usuario(cod_usuario)
);

delimiter $$
create trigger checar_data_publicacao
before insert on artigo
for each row
begin
  if new.data_publicacao > curdate() then
    signal sqlstate '45000'
    set message_text = 'A data de publicação não pode ser no futuro';
  end if;
end$$
delimiter ;

create table recurso_acessibilidade(
id_recurso char(3) primary key not null,
nome_recurso enum('Rampa','Piso tátil','Banheiro adaptado','Elevador','Vaga PCD','Corrimão','Sinalização em braile','Outro') not null,
categoria_recurso enum('Física','Visual','Auditiva','Intelectual') not null
);

create table possui(
id_local char(6) not null,
id_recurso char(3) not null,
situacao_recurso enum('Disponível','Indisponível','Não verificado') not null,
data_verificacao date null,
primary key (id_local, id_recurso),
foreign key (id_local) references locais(id_local),
foreign key (id_recurso) references recurso_acessibilidade(id_recurso)
);

delimiter $$
create trigger checar_data_verificacao
before insert on possui
for each row
begin
  if new.data_verificacao > curdate() then
    signal sqlstate '45000'
    set message_text = 'A data de verificação não pode ser no futuro';
  end if;
end$$
delimiter ;


insert into usuario (cod_usuario, nome_usuario, telefone, senha, email) values
('000001', 'Joni Quirino', '(41) 99985-6818', 'joni@20', 'joni_quirino@gmail.com'),
('000002', 'Joana Silva', '(41) 99747-9879', '9091silva', 'joana_silva@gmail.com'),
('000003', 'Camila Ferreira', '(41) 98833-4512', 'Cami$2025', 'camila.f@email.com'),
('000004', 'Diego Martins', '(41) 99671-0098', 'Diego@789', 'diego.martins@email.com'),
('000005', 'Eduarda Lima', '(41) 99102-7745', 'Duda!4567', 'eduarda.lima@email.com');
insert into locais (id_local, nome_local, longitude, latitude, rua_endereco, bairro_endereco, num_endereco, complemento_endereco, categoria_local) values
('000001', 'Farmácia Saúde Viva', -49.271120, -25.429510, 'Rua XV de Novembro', 'Centro', '850', null, 'Saúde'),
('000002', 'Colégio Estadual Monteiro Lobato', -49.284530, -25.441220, 'Rua Brigadeiro Franco', 'Rebouças', '1520', null, 'Educação'),
('000003', 'Supermercado Bom Preço', -49.247810, -25.454330, 'Avenida Comendador Franco', 'Jardim Botânico', '2300', null, 'Comércio'),
('000004', 'Unidade de Saúde Batel', -49.290040, -25.442870, 'Avenida Sete de Setembro', 'Batel', '4100', null, 'Saúde'),
('000005', 'Biblioteca Pública do Paraná', -49.267320, -25.433680, 'Rua Cândido Lopes', 'Centro', '133', null, 'Educação');

insert into denuncia (id_denuncia, cod_usuario, id_local, descricao_denuncia, situacao_denuncia, data_denuncia) values
('0001', '000003', '000002', 'Entrada principal só tem escadas, sem rampa.', 'Pendente', '2026-03-21'),
('0002', '000001', '000001', 'Balcão de atendimento alto demais para cadeirantes.', 'Pendente', '2026-04-08'),
('0003', '000005', '000003', 'Banheiro adaptado sempre trancado.', 'Em análise', '2026-04-30'),
('0004', '000002', '000004', 'Elevador parado há mais de um mês.', 'Resolvida', '2026-05-12'),
('0005', '000004', '000005', 'Sinalização em braile ilegível no balcão.', 'Pendente', '2026-05-27'),
('0006', '000003', '000003', 'Vagas PCD ocupadas por carros sem credencial.', 'Pendente', '2026-06-15'),
('0007', '000001', '000002', 'Corrimão da escada lateral solto.', 'Pendente', '2026-07-02'),
('0008', '000005', '000001', 'Rampa da entrada com inclinação muito forte.', 'Rejeitada', '2026-07-23'),
('0009', '000002', '000005', 'Falta piso tátil na entrada.', 'Pendente', '2026-08-09'),
('0010', '000004', '000004', 'Porta do banheiro adaptado estreita demais.', 'Pendente', '2026-09-18');

insert into avaliacao (id_avaliacao, nota, descricao, data_avaliacao, cod_usuario, id_local) values
('0001', 4.50, 'Rampa na entrada e atendimento muito atencioso.', '2026-03-12', '000001', '000001'),
('0002', 2.00, 'Escadas na entrada e nenhum corrimão.', '2026-03-20', '000003', '000002'),
('0003', 3.50, 'Tem vaga PCD, mas o banheiro adaptado estava trancado.', '2026-04-02', '000005', '000003'),
('0004', 5.00, 'Totalmente acessível, com piso tátil e elevador.', '2026-04-15', '000002', '000004'),
('0005', 4.00, 'Bom acesso, mas a sinalização em braile está gasta.', '2026-05-03', '000004', '000005'),
('0006', 4.50, 'Elevador funcionando e funcionários prestativos.', '2026-06-10', '000003', '000005'),
('0007', 1.50, 'Degrau alto na porta, sem rampa.', '2026-06-22', '000004', '000002'),
('0008', 4.00, 'Corredores largos e bem sinalizados.', '2026-07-05', '000001', '000003'),
('0009', 5.00, 'Excelente, voltarei com certeza.', '2026-08-25', '000005', '000001'),
('0010', 4.50, null, '2026-09-14', '000002', '000004');

insert into solicitacao (id_solicitacao, cod_usuario, item_solicitado, descricao_solicitacao, urgencia_solicitacao, data_solicitacao, situacao_solicitacao) values
('0001', '000001', 'Equipamento', 'Cadeira de rodas nova, a atual está com a roda quebrada.', 'Alta', '2026-02-10', 'Aberta'),
('0002', '000003', 'Equipamento', 'Bengala dobrável para deficiência visual.', 'Média', '2026-03-05', 'Atendida'),
('0003', '000004', 'Dinheiro', 'Ajuda para comprar baterias do aparelho auditivo.', 'Alta', '2026-03-28', 'Aberta'),
('0004', '000002', 'Alimento', 'Cesta básica para a família.', 'Alta', '2026-04-14', 'Aberta'),
('0005', '000005', 'Equipamento', 'Almofada antiescaras para cadeira de rodas.', 'Baixa', '2026-05-02', 'Aberta'),
('0006', '000003', 'Vestuário', 'Roupas de inverno tamanho M.', 'Média', '2026-05-20', 'Em andamento'),
('0007', '000001', 'Dinheiro', 'Ajuda com transporte para sessões de fisioterapia.', 'Alta', '2026-06-25', 'Aberta'),
('0008', '000004', 'Outro', 'Curso de leitura em braile.', 'Baixa', '2026-07-11', 'Cancelada'),
('0009', '000002', 'Alimento', 'Leite e fraldas geriátricas.', 'Alta', '2026-08-03', 'Aberta'),
('0010', '000005', 'Equipamento', 'Andador com rodas.', 'Alta', '2026-09-20', 'Aberta');









insert into artigo (id_artigo, cod_usuario, titulo_artigo, conteudo_artigo, data_publicacao, situacao_artigo) values
('0001', '000003', 'O que é acessibilidade de verdade?',
'Acessibilidade não é só colocar uma rampa na entrada. É pensar em todas as pessoas que vão usar aquele espaço: quem usa cadeira de rodas, quem tem baixa visão, quem é surdo, quem tem deficiência intelectual e também idosos e gestantes.\n\nUm lugar acessível tem rampas com inclinação correta, piso tátil, banheiro adaptado, sinalização em braile e atendimento preparado. Quando falta uma dessas coisas, alguém fica de fora.\n\nPor isso é tão importante avaliar e denunciar os lugares aqui no Ponte: cada avaliação ajuda outra pessoa a decidir aonde ir.',
'2026-08-12', 'Publicado'),
('0002', '000001', 'Dicas para quem vai doar equipamentos',
'Cadeiras de rodas, andadores e muletas fazem muita diferença na vida de quem precisa. Antes de doar, confira se o equipamento está limpo e funcionando: rodas girando, freios segurando e nenhuma peça solta.\n\nSe possível, informe na descrição da doação o tamanho e o estado do equipamento. Isso ajuda a encontrar a pessoa certa mais rápido.\n\nE lembre: na página de Doações e solicitações você pode clicar em "Quero ajudar" para doar direto para quem pediu.',
'2026-09-03', 'Publicado'),
('0003', '000005', 'Piso tátil: para que serve?',
'O piso tátil é aquele piso com relevo que aparece em calçadas e estações. Ele guia pessoas cegas ou com baixa visão, que sentem o relevo com os pés ou com a bengala.\n\nExistem dois tipos: o direcional, com linhas retas, que mostra o caminho; e o de alerta, com bolinhas, que avisa sobre obstáculos, escadas ou mudanças de direção.\n\nQuando o piso tátil está quebrado ou leva direto para um poste, ele atrapalha mais do que ajuda. Se você vir isso, faça uma denúncia!',
'2026-10-20', 'Publicado');
