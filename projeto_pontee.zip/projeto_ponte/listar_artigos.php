<?php
    if (session_id() == "") {
        session_start();
    }

    include('conexao.php');

    header('Content-Type: application/json; charset=utf-8');

    // listar_artigos.php            -> artigos publicados (todo mundo)
    // listar_artigos.php?meus=1     -> artigos de quem está logado (publicados e rascunhos)
    // listar_artigos.php?busca=rampa -> procura no título e no texto
    $meus = isset($_GET["meus"]) ? $_GET["meus"] : "";
    $busca = isset($_GET["busca"]) ? trim($_GET["busca"]) : "";
    $busca = $conn->real_escape_string($busca);

    $sql = "SELECT a.id_artigo, a.titulo_artigo, a.conteudo_artigo, a.data_publicacao,
                   a.situacao_artigo, u.nome_usuario
            FROM artigo a
            JOIN usuario u ON u.cod_usuario = a.cod_usuario";

    if ($meus == "1") {
        if (!isset($_SESSION["cod_usuario"])) {
            echo json_encode([]);
            exit;
        }
        $codUsuario = $_SESSION["cod_usuario"];
        $sql = $sql . " WHERE a.cod_usuario = '$codUsuario' AND a.situacao_artigo <> 'Removido'";
    }
    else {
        $sql = $sql . " WHERE a.situacao_artigo = 'Publicado'";
    }

    if ($busca != "") {
        $sql = $sql . " AND (a.titulo_artigo LIKE '%$busca%' OR a.conteudo_artigo LIKE '%$busca%')";
    }

    $sql = $sql . " ORDER BY a.data_publicacao DESC, a.id_artigo DESC";

    $result = $conn->query($sql);

    $artigos = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            // prévia: só o começo do texto (aula de Strings - substr)
            // mb_substr é o substr que não corta letras com acento no meio
            $texto = trim($row["conteudo_artigo"]);
            $previa = $texto;
            if (mb_strlen($texto) > 180) {
                $previa = trim(mb_substr($texto, 0, 180)) . "...";
            }

            $artigos[] = [
                "id" => $row["id_artigo"],
                "titulo" => $row["titulo_artigo"],
                "previa" => $previa,
                "situacao" => $row["situacao_artigo"],
                "data" => date("d/m/Y", strtotime($row["data_publicacao"])),
                "autor" => $row["nome_usuario"]
            ];
        }
    }

    $conn->close();

    echo json_encode($artigos);
?>
