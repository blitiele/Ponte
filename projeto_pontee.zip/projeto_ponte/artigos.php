<?php
    if (session_id() == "") {
        session_start();
    }
    $logado = isset($_SESSION["logado"]);
    $nome = isset($_SESSION["nome_usuario"]) ? $_SESSION["nome_usuario"] : "";
    $pagina = "artigos.php";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Artigos | Ponte</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;500;600;700&display=swap">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/paginas.css">
</head>
<body>

<header>
  <div class="acesso">
    <?php if ($logado) { ?>
      <span class="usuario"><?=htmlspecialchars($nome)?></span>
      <a href="logout.php">Sair</a>
    <?php } else { ?>
      <a href="login.php">Entrar</a>
      <a href="cadastro.php">Cadastrar</a>
    <?php } ?>
  </div>

  <h1>Artigos</h1>
  <p class="subtitulo">Leia e escreva conteúdos sobre inclusão e acessibilidade.</p>

  <?php include('menu.php'); ?>
</header>

<main>
  <section class="blocos">

    <article class="bloco">
      <h2>Escrever um artigo</h2>

      <?php if ($logado) { ?>
        <form id="form-artigo">
          <label for="titulo">Título</label>
          <input type="text" id="titulo" maxlength="100" required>

          <label for="conteudo">Texto</label>
          <textarea id="conteudo" rows="12" required
            placeholder="Escreva aqui. Deixe uma linha em branco para começar um novo parágrafo."></textarea>
          <p id="contador" class="dica">0 caracteres</p>

          <label for="situacao">Ao salvar</label>
          <select id="situacao">
            <option value="Publicado">Publicar agora</option>
            <option value="Rascunho">Guardar como rascunho (só você vê)</option>
          </select>

          <button type="submit">Salvar artigo</button>
          <p id="msg-artigo" class="mensagem" role="status"></p>
        </form>
      <?php } else { ?>
        <p class="aviso"><a href="login.php">Entre na sua conta</a> para escrever um artigo.</p>
      <?php } ?>

      <?php if ($logado) { ?>
        <h2>Meus artigos</h2>
        <ul id="meus-artigos" class="lista-cartoes"></ul>
      <?php } ?>
    </article>



    <article class="bloco bloco-largo">
      <h2>Artigos publicados</h2>

      <label for="busca">Buscar</label>
      <input type="search" id="busca" class="filtro" placeholder="Digite uma palavra do título ou do texto">

      <ul id="lista-artigos" class="lista-cartoes"></ul>
    </article>






  </section>
</main>

<script src="js/artigos.js"></script>
</body>
</html>
