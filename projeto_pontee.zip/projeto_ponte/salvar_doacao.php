<?php
    if (session_id() == "") {
        session_start();
    }

    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION["logado"])) {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Entre na sua conta para registrar uma doação."
        ]);
        exit;
    }

    $dados = json_decode(
        file_get_contents("php://input"),
        true
    );

    $idSolicitacao = isset($dados["id_solicitacao"]) ? $dados["id_solicitacao"] : "";
    $item = isset($dados["item"]) ? $dados["item"] : "";
    $quantidade = isset($dados["quantidade"]) ? $dados["quantidade"] : "";
    $descricao = isset($dados["descricao"]) ? trim($dados["descricao"]) : "";
    $codUsuario = $_SESSION["cod_usuario"];

    $itens = ["Dinheiro", "Alimento", "Vestuário", "Equipamento", "Outro"];

    $erro = "";

    if (!in_array($item, $itens)) {
        $erro = "Escolha o tipo do que você vai doar.";
    }
    else if (!is_numeric($quantidade) || $quantidade <= 0) {
        $erro = "Informe uma quantidade maior que zero.";
    }

    if ($erro != "") {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => $erro
        ]);
        exit;
    }

    include('conexao.php');

    $descricao = $conn->real_escape_string($descricao);
    $idSolicitacao = $conn->real_escape_string($idSolicitacao);

    // 1) se escolheu uma solicitação, confere se ela existe e ainda está aberta
    if ($idSolicitacao != "") {
        $sql = "SELECT situacao_solicitacao FROM solicitacao WHERE id_solicitacao = '$idSolicitacao'";
        $result = $conn->query($sql);

        if ($result->num_rows == 0) {
            echo json_encode([
                "sucesso" => false,
                "mensagem" => "Essa solicitação não existe."
            ]);
            $conn->close();
            exit;
        }

        $row = $result->fetch_assoc();

        if ($row["situacao_solicitacao"] == "Atendida" || $row["situacao_solicitacao"] == "Cancelada") {
            echo json_encode([
                "sucesso" => false,
                "mensagem" => "Essa solicitação já foi encerrada."
            ]);
            $conn->close();
            exit;
        }
    }

    // 2) próximo id (0001, 0002, ...)
    $sql = "SELECT MAX(id_doacao) AS ultimo FROM doacao";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $id = str_pad($row["ultimo"] + 1, 4, "0", STR_PAD_LEFT);

    // 3) id_solicitacao é NULL quando é uma doação geral
    if ($idSolicitacao == "") {
        $valorSolicitacao = "NULL";
    }
    else {
        $valorSolicitacao = "'$idSolicitacao'";
    }

    $sql = "INSERT INTO doacao (id_doacao, cod_usuario, id_solicitacao, tipo_item, descricao_doacao,
                                data_doacao, quantidade_doada, situacao_doacao)
            VALUES ('$id', '$codUsuario', $valorSolicitacao, '$item', '$descricao',
                    CURDATE(), $quantidade, 'Disponível')";

    if ($conn->query($sql) === TRUE) {

        // 4) a solicitação que recebeu a doação passa para "Em andamento"
        if ($idSolicitacao != "") {
            $sql = "UPDATE solicitacao SET situacao_solicitacao = 'Em andamento'
                    WHERE id_solicitacao = '$idSolicitacao' AND situacao_solicitacao = 'Aberta'";
            $conn->query($sql);
        }

        echo json_encode([
            "sucesso" => true,
            "mensagem" => "Doação registrada! Muito obrigado."
        ]);
    }
    else {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Não foi possível registrar a doação. Tente novamente."
        ]);
    }

    $conn->close();
?>
